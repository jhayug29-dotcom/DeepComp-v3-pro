#!/bin/bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
ROOT="$(cd "$SCRIPT_DIR/.." && pwd)"
EXT_SRC="$ROOT/com.yugz.deepcomp"
EXT_ID="com.yugz.deepcomp"
CEP_ROOT="$HOME/Library/Application Support/Adobe/CEP/extensions"
INSTALL_PATH="$CEP_ROOT/$EXT_ID"
LIBRARY_PATH="$HOME/Library/Application Support/DeepComp/yugz.fx"
BACKUP_ROOT="$HOME/Library/Application Support/DeepComp/InstallerBackups/$(date +%Y%m%d-%H%M%S)"

ok(){ echo "  OK  $1"; }
warn(){ echo "  !   $1"; }
step(){ echo; echo "[$1]"; }

printf '\nDeepComp Panel — Automatic macOS Setup\n\n'

if [[ ! -d "$EXT_SRC" ]]; then
  echo "DeepComp payload not found: $EXT_SRC"; exit 1
fi

step "Detecting After Effects installations"
AE_APPS=()
while IFS= read -r -d '' app; do AE_APPS+=("$app"); done < <(find /Applications -maxdepth 3 -type d -name 'Adobe After Effects*.app' -print0 2>/dev/null || true)
if [[ ${#AE_APPS[@]} -eq 0 ]]; then
  warn "No installed After Effects application was detected. The panel will still be installed."
else
  for app in "${AE_APPS[@]}"; do
    ver="unknown"
    if [[ -f "$app/Contents/Info.plist" ]]; then
      ver=$(/usr/libexec/PlistBuddy -c 'Print:CFBundleShortVersionString' "$app/Contents/Info.plist" 2>/dev/null || echo unknown)
    fi
    ok "$(basename "$app" .app) — $ver"
  done
fi

step "Enabling CEP developer extensions for CSXS 5–15"
for n in $(seq 5 15); do
  defaults write "com.adobe.CSXS.$n" PlayerDebugMode -string 1 >/dev/null
 done
ok "CEP unsigned-extension mode enabled for the current user."

step "Backing up existing DeepComp installation/library"
if [[ -d "$INSTALL_PATH" ]]; then
  mkdir -p "$BACKUP_ROOT"
  ditto "$INSTALL_PATH" "$BACKUP_ROOT/$EXT_ID"
  ok "Existing panel backed up."
fi
if [[ -d "$LIBRARY_PATH" ]]; then
  mkdir -p "$BACKUP_ROOT"
  ditto "$LIBRARY_PATH" "$BACKUP_ROOT/Library"
  ok "Existing DeepComp library backed up."
fi

step "Installing DeepComp panel"
mkdir -p "$CEP_ROOT"
rm -rf "$INSTALL_PATH"
ditto "$EXT_SRC" "$INSTALL_PATH"
ok "Installed to $INSTALL_PATH"

step "Installing bundled After Effects presets"
PRESET_SRC="$EXT_SRC/presets"
PRESETS=()
while IFS= read -r -d '' f; do PRESETS+=("$f"); done < <(find "$PRESET_SRC" -type f -name '*.ffx' -print0 2>/dev/null || true)
if [[ ${#AE_APPS[@]} -gt 0 && ${#PRESETS[@]} -gt 0 ]]; then
  for app in "${AE_APPS[@]}"; do
    ver=$(/usr/libexec/PlistBuddy -c 'Print:CFBundleShortVersionString' "$app/Contents/Info.plist" 2>/dev/null || true)
    if [[ -z "$ver" ]]; then ver="$(basename "$app" .app | sed -E 's/.*[^0-9]([0-9]{4})$/\1/')"; fi
    DEST="$HOME/Documents/Adobe/After Effects $ver/User Presets/DeepComp"
    mkdir -p "$DEST"
    for f in "${PRESETS[@]}"; do
      name="$(basename "$f")"
      # Trim accidental whitespace before the .ffx extension.
      name="$(printf '%s' "$name" | sed -E 's/[[:space:]]+\.ffx$/.ffx/')"
      cp -f "$f" "$DEST/$name"
    done
    ok "Presets installed for $(basename "$app" .app)"
  done
else
  warn "No presets copied because no AE installation/preset files were detected."
fi

step "Creating user library folder"
mkdir -p "$LIBRARY_PATH"
ok "$LIBRARY_PATH"

step "Installation verification"
[[ -f "$INSTALL_PATH/CSXS/manifest.xml" ]] && [[ -f "$INSTALL_PATH/index.html" ]]
ok "Panel payload and manifest verified."

echo
echo "DONE — Restart After Effects, then open Window > Extensions > deepcomp panel by yugz.fx."
echo "DeepComp detects the running AE version inside the panel and applies version-specific capabilities/settings on first launch."
echo
echo "Press Enter to close."
read -r
