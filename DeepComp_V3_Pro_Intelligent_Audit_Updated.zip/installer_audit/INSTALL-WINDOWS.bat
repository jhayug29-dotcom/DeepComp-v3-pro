@echo off
setlocal
cd /d "%~dp0"
if not exist "%~dp0Installers\Install-Windows.ps1" (
  echo DeepComp installer files are missing.
  pause
  exit /b 1
)
where powershell.exe >nul 2>&1 || (echo PowerShell is required.& pause & exit /b 1)
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0Installers\Install-Windows.ps1"
exit /b %errorlevel%
