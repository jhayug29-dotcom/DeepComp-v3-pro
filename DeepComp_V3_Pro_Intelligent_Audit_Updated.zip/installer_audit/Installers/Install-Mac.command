#!/bin/bash
set -euo pipefail
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
ROOT="$(cd "$SCRIPT_DIR/.." && pwd)"
EXT_SRC="$ROOT/com.yugz.deepcomp"
EXT_ID="com.yugz.deepcomp"
CEP_ROOT="$HOME/Library/Application Support/Adobe/CEP/extensions"
INSTALL_PATH="$CEP_ROOT/$EXT_ID"
LIBRARY_PATH="$HOME/Library/Application Support/DeepComp/yugz.fx"
BACKUP_ROOT="$HOME/Library/Application Support/DeepComp/InstallerBackups/$(date +%Y%m%d-%H%M%S)"
ok(){ echo "  OK  $1"; }; warn(){ echo "  !   $1"; }; step(){ echo; echo "[$1]"; }
echo; echo "DeepComp Panel — macOS Auto Installer"; echo
[[ -d "$EXT_SRC" ]] || { echo "Panel payload not found: $EXT_SRC"; exit 1; }
step "Detecting installed After Effects"
AE_APPS=(); while IFS= read -r -d '' app; do AE_APPS+=("$app"); done < <(find /Applications "$HOME/Applications" -maxdepth 3 -type d -name 'Adobe After Effects*.app' -print0 2>/dev/null || true)
if [[ ${#AE_APPS[@]} -eq 0 ]]; then warn "No After Effects installation found. Panel will still be installed."; else for app in "${AE_APPS[@]}"; do v=$(/usr/libexec/PlistBuddy -c 'Print:CFBundleShortVersionString' "$app/Contents/Info.plist" 2>/dev/null || echo unknown); ok "$(basename "$app" .app) — $v"; done; fi
step "Enabling CEP developer mode"
for n in $(seq 6 12); do defaults write "com.adobe.CSXS.$n" PlayerDebugMode -string 1 >/dev/null; done
ok "CEP PlayerDebugMode enabled for current macOS user."
step "Backing up existing panel"
if [[ -d "$INSTALL_PATH" ]]; then mkdir -p "$BACKUP_ROOT"; ditto "$INSTALL_PATH" "$BACKUP_ROOT/$EXT_ID"; ok "Backup: $BACKUP_ROOT"; fi
step "Installing panel to current-user CEP folder"
mkdir -p "$CEP_ROOT"; rm -rf "$INSTALL_PATH"; ditto "$EXT_SRC" "$INSTALL_PATH"; ok "$INSTALL_PATH"
step "Installing presets for each detected AE version"
PRESET_SRC="$EXT_SRC/presets"; mapfile -d '' PRESETS < <(find "$PRESET_SRC" -type f -name '*.ffx' -print0 2>/dev/null || true)
for app in "${AE_APPS[@]}"; do
  v=$(/usr/libexec/PlistBuddy -c 'Print:CFBundleShortVersionString' "$app/Contents/Info.plist" 2>/dev/null || true); year=$(basename "$app" .app | grep -oE '[0-9]{4}$' || true); [[ -n "$year" ]] || year=$(printf '%s' "$v" | grep -oE '^[0-9]{4}' || true)
  if [[ -z "$year" ]]; then warn "Could not determine AE year for $(basename "$app")"; continue; fi
  DEST="$HOME/Documents/Adobe/After Effects $year/User Presets/DeepComp"; mkdir -p "$DEST"
  for f in "${PRESETS[@]}"; do [[ -n "$f" ]] || continue; cp -f "$f" "$DEST/$(basename "$f" | sed -E 's/[[:space:]]+\.ffx$/.ffx/')"; done
  ok "Presets: $DEST"
done
step "Creating DeepComp data folder"; mkdir -p "$LIBRARY_PATH"; ok "$LIBRARY_PATH"
step "Verifying installation"; [[ -f "$INSTALL_PATH/CSXS/manifest.xml" && -f "$INSTALL_PATH/index.html" ]] || { echo "Verification failed."; exit 1; }; ok "Manifest + panel entry point verified."
echo; echo "INSTALL COMPLETE"; echo "Restart After Effects completely, then open Window > Extensions > deepcomp panel by yugz.fx."; echo; read -r -p "Press Enter to close."
