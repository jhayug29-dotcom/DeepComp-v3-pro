$ErrorActionPreference = 'Stop'
$Host.UI.RawUI.WindowTitle = 'DeepComp — Windows Installer'

$scriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$root = Split-Path -Parent $scriptDir
$extensionSource = Join-Path $root 'com.yugz.deepcomp'
$extensionId = 'com.yugz.deepcomp'
$cepRoot = Join-Path $env:APPDATA 'Adobe\CEP\extensions'
$installPath = Join-Path $cepRoot $extensionId
$libraryPath = Join-Path $env:APPDATA 'DeepComp\yugz.fx'
$backupRoot = Join-Path $env:APPDATA ('DeepComp\InstallerBackups\' + (Get-Date -Format 'yyyyMMdd-HHmmss'))

function Step($s){Write-Host "`n[$s]" -ForegroundColor Cyan}
function Ok($s){Write-Host "  OK  $s" -ForegroundColor Green}
function Warn($s){Write-Host "  !   $s" -ForegroundColor Yellow}

Write-Host "`nDeepComp Panel — Windows Auto Installer`n" -ForegroundColor White
if(-not(Test-Path $extensionSource -PathType Container)){throw "Panel payload not found: $extensionSource"}

Step 'Detecting installed After Effects'
$aeDirs = @()
$adobeRoots = @($env:ProgramFiles, ${env:ProgramFiles(x86)}) | Where-Object {$_ -and (Test-Path (Join-Path $_ 'Adobe'))} | ForEach-Object {Join-Path $_ 'Adobe'}
foreach($base in $adobeRoots){$aeDirs += Get-ChildItem $base -Directory -ErrorAction SilentlyContinue | Where-Object {$_.Name -match '^Adobe After Effects(?: \d{4})?$'}}
$aeDirs = @($aeDirs | Sort-Object FullName -Unique)
$ae = @()
foreach($d in $aeDirs){
  $exe=Join-Path $d.FullName 'Support Files\AfterFX.exe'; $v=''
  if(Test-Path $exe){try{$v=(Get-Item $exe).VersionInfo.ProductVersion}catch{}}
  if(-not $v -and $d.Name -match '(\d{4})'){$v=$Matches[1]}
  $ae += [pscustomobject]@{Name=$d.Name;Path=$d.FullName;Version=$v}
  Ok "$($d.Name) — $v"
}
if($ae.Count -eq 0){Warn 'No After Effects installation found. Panel will still be installed.'}

Step 'Enabling CEP developer mode'
# Covers modern CEP generations while remaining harmless for unused keys.
foreach($n in 6..12){$key="HKCU:\Software\Adobe\CSXS.$n";New-Item $key -Force | Out-Null;New-ItemProperty $key PlayerDebugMode -PropertyType String -Value '1' -Force | Out-Null}
Ok 'CEP PlayerDebugMode enabled for current Windows user.'

Step 'Backing up existing panel'
if(Test-Path $installPath){New-Item $backupRoot -ItemType Directory -Force | Out-Null;Copy-Item $installPath (Join-Path $backupRoot $extensionId) -Recurse -Force;Ok "Backup: $backupRoot"}

Step 'Installing panel to current-user CEP folder'
New-Item $cepRoot -ItemType Directory -Force | Out-Null
if(Test-Path $installPath){Remove-Item $installPath -Recurse -Force}
Copy-Item $extensionSource $installPath -Recurse -Force
Ok $installPath

Step 'Installing presets for each detected AE version'
$presetSource=Join-Path $extensionSource 'presets'
$ffx=@(Get-ChildItem $presetSource -Recurse -File -Filter '*.ffx' -ErrorAction SilentlyContinue)
foreach($a in $ae){
  $year=''
  if($a.Name -match '(\d{4})'){$year=$Matches[1]} elseif($a.Version -match '(\d{4})'){$year=$Matches[1]}
  if(-not $year){Warn "Could not determine AE year for $($a.Name); skipping presets.";continue}
  $dest=Join-Path $env:USERPROFILE "Documents\Adobe\After Effects $year\User Presets\DeepComp"
  New-Item $dest -ItemType Directory -Force | Out-Null
  foreach($f in $ffx){Copy-Item $f.FullName (Join-Path $dest $f.Name.Trim()) -Force}
  Ok "Presets: $dest"
}

Step 'Creating DeepComp data folder'
New-Item $libraryPath -ItemType Directory -Force | Out-Null

Step 'Verifying installation'
if(!(Test-Path (Join-Path $installPath 'CSXS\manifest.xml')) -or !(Test-Path (Join-Path $installPath 'index.html'))){throw 'Verification failed: manifest/index missing.'}
Ok 'Manifest + panel entry point verified.'
Write-Host "`nINSTALL COMPLETE`nRestart After Effects completely, then open Window > Extensions > deepcomp panel by yugz.fx.`n" -ForegroundColor Green
Read-Host 'Press Enter to close'
