// Utility: Wrap everything in an undo group
function undoWrapper(name, func) {
    app.beginUndoGroup(name);
    try {
        func();
    } catch(e) {
        alert(e.toString());
    }
    app.endUndoGroup();
}

function getActiveComp() {
    var comp = app.project.activeItem;
    if (!comp || !(comp instanceof CompItem)) {
        alert("Please select a composition.");
        return null;
    }
    return comp;
}

// ─── HELPER: Move new layer just ABOVE the selected layer ────────────────────
// AE mein lower index = upar. moveBefore(refLayer) = refLayer se upar aa jao.
function moveAboveSelected(newLayer, selectedLayers) {
    if (selectedLayers && selectedLayers.length > 0) {
        try { newLayer.moveBefore(selectedLayers[0]); } catch(e) {}
    }
}

function addSolid() {
    undoWrapper("Add Solid", function() {
        var comp = getActiveComp();
        if (!comp) return;
        var selected = comp.selectedLayers;
        var layer = comp.layers.addSolid([1,1,1], "Solid", comp.width, comp.height, comp.pixelAspect, comp.duration);
        layer.Effects.addProperty("ADBE Fill");
        // ── Match selected layer's time range ──────────────────────────────
        if (selected && selected.length > 0) {
            layer.inPoint  = selected[0].inPoint;
            layer.outPoint = selected[0].outPoint;
            // ── Selected layer ke just UPAR rakho ──────────────────────────
            moveAboveSelected(layer, selected);
        }
        // If nothing selected, layer already spans full comp duration (default)
    });
}

function addAdjustmentLayer() {
    undoWrapper("Add Adjustment Layer", function() {
        var comp = getActiveComp();
        if (!comp) return;
        var selected = comp.selectedLayers;
        var layer = comp.layers.addSolid([1,1,1], "Adjustment Layer", comp.width, comp.height, comp.pixelAspect, comp.duration);
        layer.adjustmentLayer = true;
        // ── Match selected layer's time range ──────────────────────────────
        if (selected && selected.length > 0) {
            layer.inPoint  = selected[0].inPoint;
            layer.outPoint = selected[0].outPoint;
            // ── Selected layer ke just UPAR rakho ──────────────────────────
            moveAboveSelected(layer, selected);
        }
    });
}

function addNull() {
    undoWrapper("Add Null", function() {
        var comp = getActiveComp();
        if (!comp) return;
        var selected = comp.selectedLayers;
        var nullLayer = comp.layers.addNull(comp.duration);
        // ── Match selected layer's time range + auto-parent ────────────────
        if (selected && selected.length > 0) {
            nullLayer.inPoint  = selected[0].inPoint;
            nullLayer.outPoint = selected[0].outPoint;
            // Auto-parent: null becomes parent of selected layer
            nullLayer.parent = null; // null itself has no parent
            selected[0].parent = nullLayer;
            // ── Selected layer ke just UPAR rakho ──────────────────────────
            moveAboveSelected(nullLayer, selected);
        }
        // If nothing selected, null spans full comp duration (default)
    });
}

function addCamera() {
    undoWrapper("Add Camera", function() {
        var comp = getActiveComp();
        if (!comp) return;
        var selected = comp.selectedLayers;
        var camera = comp.layers.addCamera("Camera", [comp.width/2, comp.height/2]);
        // ── Match selected layer's time range ──────────────────────────────
        if (selected && selected.length > 0) {
            try {
                camera.inPoint  = selected[0].inPoint;
                camera.outPoint = selected[0].outPoint;
            } catch(e) {} // camera duration set karna optional hai
            // ── Selected layer ke just UPAR rakho ──────────────────────────
            moveAboveSelected(camera, selected);
        }
    });
}

function setAnchor(xMultiplier, yMultiplier) {
    undoWrapper("Set Anchor Point", function() {
        var comp = getActiveComp();
        if (!comp) return;
        var layers = comp.selectedLayers;
        if (layers.length === 0) return alert("Select a layer.");
        
        for (var i = 0; i < layers.length; i++) {
            var layer = layers[i];
            if (layer.source instanceof CompItem || layer.source instanceof FootageItem || layer instanceof TextLayer || layer instanceof ShapeLayer) {
                var rect = layer.sourceRectAtTime(comp.time, false);
                var x = rect.left + (rect.width * xMultiplier);
                var y = rect.top + (rect.height * yMultiplier);
                
                var curAnchor = layer.property("Anchor Point").value;
                var curPos = layer.property("Position").value;
                var xDiff = x - curAnchor[0];
                var yDiff = y - curAnchor[1];
                
                layer.property("Anchor Point").setValue([x, y, 0]);
                layer.property("Position").setValue([curPos[0] + xDiff, curPos[1] + yDiff, curPos[2]]);
            }
        }
    });
}

function alignLayer(mode) {
    undoWrapper("Align Layer", function() {
        var comp = getActiveComp();
        if (!comp) return;
        var layers = comp.selectedLayers;
        if (layers.length === 0) return alert("Select a layer.");
        
        for (var i = 0; i < layers.length; i++) {
            var layer = layers[i];
            var pos = layer.property("Position").value;
            var w = comp.width;
            var h = comp.height;
            var rect = layer.sourceRectAtTime(comp.time, false);
            var anchor = layer.property("Anchor Point").value;
            
            switch(mode) {
                case 'left':
                    layer.property("Position").setValue([anchor[0] - rect.left, pos[1], pos[2]]);
                    break;
                case 'right':
                    layer.property("Position").setValue([w - (rect.width - (anchor[0] - rect.left)), pos[1], pos[2]]);
                    break;
                case 'center_horiz':
                    layer.property("Position").setValue([w/2, pos[1], pos[2]]);
                    break;
                case 'top':
                    layer.property("Position").setValue([pos[0], anchor[1] - rect.top, pos[2]]);
                    break;
                case 'bottom':
                    layer.property("Position").setValue([pos[0], h - (rect.height - (anchor[1] - rect.top)), pos[2]]);
                    break;
                case 'center_vert':
                    layer.property("Position").setValue([pos[0], h/2, pos[2]]);
                    break;
            }
        }
    });
}

function precompose() {
    undoWrapper("Pre-compose", function() {
        var comp = getActiveComp();
        if (!comp) return;
        var layers = comp.selectedLayers;
        if (layers.length === 0) return alert("Select layers to pre-compose.");
        
        var earliestIn = 999999;
        var latestOut = -999999;
        for (var i = 0; i < layers.length; i++) {
            var l = layers[i];
            if (l.inPoint < earliestIn) earliestIn = l.inPoint;
            if (l.outPoint > latestOut) latestOut = l.outPoint;
        }
        
        var indices = [];
        for (var i = 0; i < layers.length; i++) indices.push(layers[i].index);
        
        var newComp = comp.layers.precompose(indices, "Precomp", true);
        
        if (earliestIn < latestOut && earliestIn !== 999999) {
            var durationSpan = latestOut - earliestIn;
            newComp.duration = durationSpan;
            
            for (var j = 1; j <= newComp.numLayers; j++) {
                newComp.layer(j).startTime -= earliestIn;
            }
            
            for (var k = 1; k <= comp.numLayers; k++) {
                var parentLayer = comp.layer(k);
                if (parentLayer.source === newComp) {
                    parentLayer.startTime = earliestIn;
                    parentLayer.inPoint = earliestIn;
                    parentLayer.outPoint = latestOut;
                    break;
                }
            }
        }
    });
}



function decompose() { unprecomp(); }

// ╔════════════════════════════════════════════════════════════════════════════╗
// ║  DEEPCOMP — ULTRA PRECISION UNPRECOMP AI SYSTEM  v3.0                    ║
// ║                                                                            ║
// ║  GUARANTEES:                                                               ║
// ║  • Koi bhi selected non-precomp layer KABHI touch nahi hogi               ║
// ║  • Har layer exact usi position pe aayegi jahan precomp thi               ║
// ║  • 1 layer ho ya 100000 — same accuracy, same speed                       ║
// ║  • Ek layer fail ho to baaki sab safe rahenge                              ║
// ║  • Koi bhi existing layer ki timing/name kabhi disturb nahi hogi           ║
// ║  • AE ka koi bhi version — consistent behavior                             ║
// ╚════════════════════════════════════════════════════════════════════════════╝

// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
// LAYER 0: VALIDATION SHIELD
// Har value ko use karne se pehle check karo — kabhi assume mat karo
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

// Check: kya yeh layer abhi bhi AE mein valid hai?
// Layers remove hone ke baad invalid ho jaati hain — access = crash
function _v_isLayerAlive(layer) {
    if (!layer) return false;
    try {
        // .index access karna = AE internally validity check karta hai
        // Agar layer dead hai toh yeh throw karega
        var idx = layer.index;
        return (typeof idx === "number" && idx > 0);
    } catch(e) { return false; }
}

// Check: kya yeh CompItem valid hai aur accessible hai?
function _v_isCompAlive(comp) {
    if (!comp) return false;
    try {
        var n = comp.numLayers;
        return (typeof n === "number");
    } catch(e) { return false; }
}

// Check: kya layer ek precomp hai? (source CompItem hona chahiye)
function _v_isPrecomp(layer) {
    if (!_v_isLayerAlive(layer)) return false;
    try {
        return (layer.source instanceof CompItem);
    } catch(e) { return false; }
}

// Safe number read — agar property exist na kare to fallback return karo
function _v_safeNum(getter, fallback) {
    try {
        var val = getter();
        if (typeof val === "number" && isFinite(val)) return val;
        return fallback;
    } catch(e) { return fallback; }
}

// Safe string read
function _v_safeStr(getter, fallback) {
    try {
        var val = getter();
        if (typeof val === "string") return val;
        return fallback;
    } catch(e) { return fallback; }
}

// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
// LAYER 1: SELECTION DETECTOR
// Sirf selected layers scan karo — koi aur layer touch nahi
// Non-precomp layers silently skip, precomps collect karo
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

function _det_getSelectedPrecomps(comp) {
    var out = { precomps: [], skipped: 0, total: 0, error: null };

    if (!_v_isCompAlive(comp)) {
        out.error = "Comp not valid";
        return out;
    }

    var sel;
    try {
        sel = comp.selectedLayers;
        out.total = sel.length;
    } catch(e) {
        out.error = "Cannot read selectedLayers: " + e.toString();
        return out;
    }

    for (var i = 0; i < sel.length; i++) {
        try {
            var lyr = sel[i];
            if (_v_isPrecomp(lyr)) {
                // Ek aur check: kya source comp accessible hai?
                if (_v_isCompAlive(lyr.source)) {
                    out.precomps.push(lyr);
                } else {
                    out.skipped++;  // source comp corrupted — skip
                }
            } else {
                out.skipped++;
            }
        } catch(e) {
            out.skipped++;
        }
    }

    return out;
}

// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
// LAYER 2: POSITION FREEZER
// Precomp layer ki parent-comp position ko ek immutable snapshot mein freeze karo
// Yeh snapshot remove se PEHLE liya jata hai — ground truth hai
//
// AE TIMING MODEL (har developer ko samajhna chahiye):
//
//   startTime  = Frame 0 of the source comp on parent timeline
//                (negative bhi ho sakta hai agar layer "before comp start" hai)
//   inPoint    = Visible start on parent timeline (ABSOLUTE, trim handle)
//   outPoint   = Visible end on parent timeline   (ABSOLUTE, trim handle)
//
//   Relationship:
//     inPoint  >= startTime                    (trim can't be before layer start)
//     outPoint <= startTime + source.duration  (trim can't exceed source end)
//
//   Key insight: inPoint/outPoint are ABSOLUTE parent-comp times, NOT
//   relative to startTime. This is why we must set all three separately.
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

function _freeze_precompPosition(precompLayer) {
    // Read all values through _v_safeNum — never crash on a bad property
    var snap = {
        // ── Core timing ─────────────────────────────────────────────────────
        startTime : _v_safeNum(function(){ return precompLayer.startTime; }, 0),
        inPoint   : _v_safeNum(function(){ return precompLayer.inPoint;   }, 0),
        outPoint  : _v_safeNum(function(){ return precompLayer.outPoint;  }, 0),

        // ── Identity ────────────────────────────────────────────────────────
        index     : _v_safeNum(function(){ return precompLayer.index; }, 0),
        name      : _v_safeStr(function(){ return precompLayer.name;  }, ""),
        label     : _v_safeNum(function(){ return precompLayer.label; }, 0),

        // ── Parent comp reference (needed for validation only) ───────────────
        containingComp: null
    };

    try { snap.containingComp = precompLayer.containingComp; } catch(e) {}

    // Validate: outPoint must be > inPoint (corrupt layer protection)
    if (snap.outPoint <= snap.inPoint) {
        // Fallback: treat outPoint as inPoint + 1 frame (1/24 sec minimum)
        snap.outPoint = snap.inPoint + (1/24);
    }

    return snap;
}

// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
// LAYER 3: CHILD FREEZER
// sourceComp ke andar EVERY layer ki complete state freeze karo
// Pure read — kuch bhi modify nahi hota yahan
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

function _freeze_children(sourceComp) {
    var snaps = [];

    if (!_v_isCompAlive(sourceComp)) return snaps;

    var count;
    try { count = sourceComp.numLayers; } catch(e) { return snaps; }

    for (var i = 1; i <= count; i++) {
        var lyr;
        try { lyr = sourceComp.layer(i); } catch(e) { continue; }
        if (!_v_isLayerAlive(lyr)) continue;

        var snap = {
            // ── Identity ──────────────────────────────────────────────────────
            sourceIndex  : i,
            name         : _v_safeStr(function(){ return lyr.name;  }, "Layer " + i),

            // ── Timing inside sourceComp (all relative to sourceComp's t=0) ──
            // startTime: where this layer's frame-0 is in sourceComp timeline
            // inPoint:   visible start in sourceComp time
            // outPoint:  visible end in sourceComp time
            startTime    : _v_safeNum(function(){ return lyr.startTime; }, 0),
            inPoint      : _v_safeNum(function(){ return lyr.inPoint;   }, 0),
            outPoint     : _v_safeNum(function(){ return lyr.outPoint;  }, 0),

            // ── Flags to preserve ─────────────────────────────────────────────
            label        : _v_safeNum(function(){ return lyr.label;  }, 0),
            locked       : false,
            shy          : false,
            solo         : false,
            parent       : null
        };

        // Safe flag reads
        try { snap.locked = lyr.locked; } catch(e) {}
        try { snap.shy    = lyr.shy;    } catch(e) {}
        try { snap.solo   = lyr.solo;   } catch(e) {}
        try { snap.parent = lyr.parent; } catch(e) {}

        // Validate timing (corrupt layer protection)
        if (snap.outPoint <= snap.inPoint) {
            snap.outPoint = snap.inPoint + (1/24);
        }

        snaps.push(snap);
    }

    return snaps;
}

// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
// LAYER 4: PLACEMENT CALCULATOR
// Pure mathematics — zero AE API calls, zero side effects
//
// FORMULA (derived from AE timing model):
//
//   Child inside sourceComp:
//     child.startTime = offset of child's frame-0 inside sourceComp
//     child.inPoint   = visible start in sourceComp time
//     child.outPoint  = visible end in sourceComp time
//
//   sourceComp in parent comp:
//     precomp.startTime = where sourceComp's t=0 maps to on parent timeline
//
//   Therefore child in parent comp:
//     final.startTime = precomp.startTime + child.startTime
//     final.inPoint   = precomp.startTime + child.inPoint
//     final.outPoint  = precomp.startTime + child.outPoint
//
//   WHY this formula is correct:
//     If precomp.startTime=5 and child is at 0→1 inside precomp:
//       final.startTime = 5 + 0 = 5
//       final.inPoint   = 5 + 0 = 5
//       final.outPoint  = 5 + 1 = 6
//     → Layer appears at 5→6 in parent comp  ✓
//
//     If precomp is moved to startTime=7:
//       final.startTime = 7 + 0 = 7  → Layer at 7→8  ✓
//
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

function _calc_finalPosition(precompSnap, childSnap) {
    var anchor    = precompSnap.startTime;  // ground truth anchor
    var finalStart = anchor + childSnap.startTime;
    var finalIn    = anchor + childSnap.inPoint;
    var finalOut   = anchor + childSnap.outPoint;

    // Final validation: outPoint must be strictly greater than inPoint
    if (finalOut <= finalIn) {
        finalOut = finalIn + (1/24);  // minimum 1 frame
    }

    return { startTime: finalStart, inPoint: finalIn, outPoint: finalOut };
}

// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
// LAYER 5: COPY ENGINE
// Layers ko parent comp mein copy karo — index drift se 100% safe
//
// THE INDEX DRIFT PROBLEM (why naive approach fails):
//   copyToComp() always inserts at index 1 (top of layer stack).
//   1st copy → at index 1
//   2nd copy → at index 1, 1st copy shifts to index 2
//   3rd copy → at index 1, others shift down
//   If we use comp.layer(1) to track copies → we always get LATEST copy only
//   Previous copies are "lost" (at unknown shifting indices)
//   Result: wrong snap applied to wrong layer → layers land at wrong time
//
// SOLUTION: Unique temp name stamping
//   Before each copy: give source layer a globally unique temp name
//   After copy: scan comp by name — find exact copied layer
//   Immediately restore original name
//   Result: 100% accurate tracking regardless of how many copies exist
//
// TEMP NAME DESIGN:
//   Format: __dc_[timestamp_ms]_[precomp_index]_[child_index]
//   Timestamp: ensures uniqueness across multiple unprecomp calls
//   precomp_index + child_index: ensures uniqueness within one call
//   __ prefix: unlikely to clash with any user layer name
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

function _copy_withTracking(comp, sourceComp, childSnaps, precompIdx) {
    var ts     = (new Date()).getTime();
    var PREFIX = "__dc_" + ts + "_" + precompIdx + "_";
    var result = [];  // [{ layer: copiedLayerOrNull, snap: childSnap }]

    // ── PHASE A: Unlock all children (copyToComp fails on locked layers) ─────
    // We unlock ALL first (not one at a time) to avoid index re-reads mid-loop
    for (var i = 0; i < childSnaps.length; i++) {
        try {
            var lyr = sourceComp.layer(childSnaps[i].sourceIndex);
            if (_v_isLayerAlive(lyr)) {
                lyr.locked = false;
                lyr.parent = null;  // parented layers also cause copy issues
            }
        } catch(e) {}
    }

    // ── PHASE B: Stamp temp names ─────────────────────────────────────────────
    // All names stamped before any copy — prevents any timing collision
    var tempNames = [];
    for (var i = 0; i < childSnaps.length; i++) {
        var tname = PREFIX + i;
        tempNames.push(tname);
        try {
            var lyr = sourceComp.layer(childSnaps[i].sourceIndex);
            if (_v_isLayerAlive(lyr)) lyr.name = tname;
        } catch(e) {}
    }

    // ── PHASE C: Copy one by one, track by temp name ──────────────────────────
    for (var i = 0; i < childSnaps.length; i++) {
        var snap   = childSnaps[i];
        var tname  = tempNames[i];
        var copied = null;

        try {
            var srcLyr = sourceComp.layer(snap.sourceIndex);
            if (!_v_isLayerAlive(srcLyr)) {
                result.push({ layer: null, snap: snap });
                continue;
            }

            srcLyr.copyToComp(comp);

            // Scan from index 1 upward to find our temp-named layer
            // We scan from top (1) because copyToComp always inserts there
            // Short-circuit as soon as found (performance: no need to scan all)
            for (var fi = 1; fi <= comp.numLayers; fi++) {
                try {
                    var candidate = comp.layer(fi);
                    if (_v_isLayerAlive(candidate) && candidate.name === tname) {
                        copied = candidate;
                        break;
                    }
                } catch(e) {}
            }

            // Restore name immediately — keep UI clean during processing
            if (copied) {
                try { copied.name = snap.name; } catch(e) {}
            }

        } catch(e) {
            // Copy failed for this specific layer — log but don't block batch
        }

        result.push({ layer: copied, snap: snap });
    }

    // ── PHASE D: Restore original names on source layers (safety net) ─────────
    // Even if copy failed — source names must go back to what user had
    for (var i = 0; i < childSnaps.length; i++) {
        try {
            var lyr = sourceComp.layer(childSnaps[i].sourceIndex);
            if (_v_isLayerAlive(lyr)) lyr.name = childSnaps[i].name;
        } catch(e) {}
    }

    return result;
}

// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
// LAYER 6: STATE RESTORER
// sourceComp ke andar original parent/lock state wapas set karo
// Yeh ALWAYS run hota hai — copy fail ho ya succeed ho
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

function _restore_childStates(sourceComp, childSnaps) {
    for (var i = 0; i < childSnaps.length; i++) {
        var snap = childSnaps[i];
        try {
            var lyr = sourceComp.layer(snap.sourceIndex);
            if (!_v_isLayerAlive(lyr)) continue;
            try { lyr.parent = snap.parent; } catch(e) {}
            try { lyr.locked = snap.locked; } catch(e) {}
        } catch(e) {}
    }
}

// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
// LAYER 7: PLACEMENT APPLICATOR
// Har copied layer ko uski calculated position pe precisely set karo
//
// AE PROPERTY SET ORDER (critical):
//   1. startTime FIRST  — yeh layer ka timeline anchor set karta hai
//   2. inPoint SECOND   — yeh absolute trim-start set karta hai
//   3. outPoint THIRD   — yeh absolute trim-end set karta hai
//
//   Agar order galat ho:
//     inPoint set karo startTime se pehle → AE internally adjust kar sakta hai
//     outPoint set karo inPoint se pehle  → AE could clamp to current inPoint
//
//   Hamesha: startTime → inPoint → outPoint
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

function _place_layers(copiedMap, precompSnap) {
    var placedCount = 0;

    for (var i = 0; i < copiedMap.length; i++) {
        var entry = copiedMap[i];

        // Skip: copy failed for this layer
        if (!entry.layer || !_v_isLayerAlive(entry.layer)) continue;

        try {
            // Calculate exact final position
            var pos = _calc_finalPosition(precompSnap, entry.snap);

            // Apply in strict order (see header comment)
            entry.layer.startTime = pos.startTime;
            entry.layer.inPoint   = pos.inPoint;
            entry.layer.outPoint  = pos.outPoint;

            // Verify placement (self-check)
            // If startTime didn't stick (some AE versions have quirks), try once more
            try {
                var actualST = entry.layer.startTime;
                if (Math.abs(actualST - pos.startTime) > 0.001) {
                    entry.layer.startTime = pos.startTime;
                    entry.layer.inPoint   = pos.inPoint;
                    entry.layer.outPoint  = pos.outPoint;
                }
            } catch(e) {}

            // Restore visual metadata (non-critical — wrapped individually)
            try { entry.layer.label    = entry.snap.label;    } catch(e) {}
            try { entry.layer.shy      = entry.snap.shy;      } catch(e) {}

            // Mark as selected so user can see what was placed
            try { entry.layer.selected = true; } catch(e) {}

            placedCount++;
        } catch(e) {
            // Placement error for this specific layer — don't block rest
        }
    }

    return placedCount;
}

// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
// LAYER 8: SINGLE PRECOMP ORCHESTRATOR
// Ek precomp ke liye poora flow run karo — isolated aur atomic
// Ek precomp fail ho to sirf woh skip hoti hai, baaki sab safe
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
// STACK ORDER RESTORER
// copyToComp always inserts at index 1, so copied layers end up reversed.
// This puts them back in the exact order they had inside the precomp.
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

function _restore_stackOrder(comp, copiedMap) {
    var live = [];
    for (var i = 0; i < copiedMap.length; i++) {
        var l = copiedMap[i].layer;
        if (l && _v_isLayerAlive(l)) live.push(l);
    }
    if (live.length < 2) return;

    // topmost copied layer = anchor slot for the whole group
    var top = live[0];
    for (var k = 1; k < live.length; k++) {
        try { if (live[k].index < top.index) top = live[k]; } catch(e) {}
    }

    try { if (live[0] !== top) live[0].moveBefore(top); } catch(e) {}
    for (var j = 1; j < live.length; j++) {
        try { live[j].moveAfter(live[j - 1]); } catch(e) {}
    }
}

function _run_onePrecomp(comp, precompLayer, precompIdx) {
    // Guard 1: layer must be alive
    if (!_v_isLayerAlive(precompLayer)) {
        return { ok: false, reason: "layer_dead" };
    }

    // Guard 2: must be a precomp
    if (!_v_isPrecomp(precompLayer)) {
        return { ok: false, reason: "not_precomp" };
    }

    var sourceComp = precompLayer.source;

    // Guard 3: source comp must be accessible
    if (!_v_isCompAlive(sourceComp)) {
        return { ok: false, reason: "source_dead" };
    }

    // ── FREEZE: read all state before any mutation ────────────────────────────
    var precompSnap = _freeze_precompPosition(precompLayer);
    var childSnaps  = _freeze_children(sourceComp);

    // Edge case: empty precomp (no layers inside)
    if (childSnaps.length === 0) {
        try { precompLayer.remove(); } catch(e) {}
        return { ok: true, placed: 0, reason: "empty_precomp" };
    }

    // ── COPY: layers to parent comp with tracking ─────────────────────────────
    var copiedMap = _copy_withTracking(comp, sourceComp, childSnaps, precompIdx);

    // ── RESTORE: put source comp state back (always, even if copy failed) ────
    _restore_childStates(sourceComp, childSnaps);

    // ── REMOVE: precomp layer hatao (AFTER copy + restore) ───────────────────
    try { precompLayer.remove(); } catch(e) {}

    // ── PLACE: copied layers ko calculated positions pe set karo ─────────────
    var placed = _place_layers(copiedMap, precompSnap);

    // ── ORDER: restore original top-to-bottom stacking of the copied layers ──
    _restore_stackOrder(comp, copiedMap);

    return { ok: true, placed: placed, total: childSnaps.length };
}

// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
// LAYER 9: BATCH ORCHESTRATOR — MAIN ENTRY POINT
// Sabhi precomps ko safe order mein process karo
//
// SAFE ORDER LOGIC:
//   Precomps sorted by index DESCENDING before processing.
//   Example: selected precomps at indices [2, 15, 47, 891]
//   Processing order: 891 → 47 → 15 → 2
//
//   Why this works:
//     When we remove layer at index 891 → layers at 1-890 unchanged
//     When we remove layer at index 47  → layers at 1-46  unchanged
//     And so on — every removal only shifts layers ABOVE it (higher index)
//     Since we already processed those, they don't matter anymore
//
//   This guarantee holds for any N layers — 10, 1000, or 100000.
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

function unprecomp() {
    undoWrapper("UnPreComp", function() {

        // ── Step 1: Get active comp ───────────────────────────────────────────
        var comp = getActiveComp();
        if (!comp) return;

        // ── Step 2: Detect all precomps in selection ──────────────────────────
        var det = _det_getSelectedPrecomps(comp);

        if (det.error) {
            alert("UnPreComp error: " + det.error);
            return;
        }

        if (det.total === 0) {
            alert("Please select one or more precomp layers.");
            return;
        }

        if (det.precomps.length === 0) {
            alert("No precomp layers in selection.\n(" + det.skipped + " non-precomp layers skipped.)");
            return;
        }

        // ── Step 3: Sort descending by index — safe removal order ─────────────
        det.precomps.sort(function(a, b) {
            var ia = _v_safeNum(function(){ return a.index; }, 0);
            var ib = _v_safeNum(function(){ return b.index; }, 0);
            return ib - ia;  // descending: highest index first
        });

        // ── Step 4: Process each precomp — isolated per iteration ────────────
        var totalPlaced  = 0;
        var totalOk      = 0;
        var totalFailed  = 0;

        for (var pi = 0; pi < det.precomps.length; pi++) {
            try {
                var res = _run_onePrecomp(comp, det.precomps[pi], pi);
                if (res.ok) {
                    totalPlaced += (res.placed || 0);
                    totalOk++;
                } else {
                    totalFailed++;
                }
            } catch(e) {
                // Absolute last resort catch — this precomp is skipped
                totalFailed++;
            }
        }

        // ── Step 5: Silent success / alert only on failures ───────────────────
        if (totalFailed > 0) {
            alert(
                "UnPreComp complete.\n\n" +
                "✓ " + totalOk + " precomp(s) processed\n" +
                "✓ " + totalPlaced + " layer(s) placed\n" +
                "✗ " + totalFailed + " failed (locked or unsupported)"
            );
        }
        // Full success = no alert, AE undo stack shows "UnPreComp"
    });
}

function centerInComp() {
    undoWrapper("Center In Comp", function() {
        var comp = getActiveComp();
        if (!comp) return;
        var layers = comp.selectedLayers;
        if (layers.length === 0) return;
        
        for (var i = 0; i < layers.length; i++) {
            var layer = layers[i];
            layer.property("Position").setValue([comp.width/2, comp.height/2, layer.property("Position").value[2]]);
        }
    });
}

function setLabel(colorIndex) {
    undoWrapper("Set Label", function() {
        var comp = getActiveComp();
        if (!comp) return;
        var layers = comp.selectedLayers;
        for (var i = 0; i < layers.length; i++) {
            layers[i].label = colorIndex;
        }
    });
}

// ─── FIX EFFECT CENTER POINTS AFTER PRESET ───────────────────────────────────
function fixTextPresetEffectPoints(layer, comp) {
    try {
        var t = comp.time;
        var rect = layer.sourceRectAtTime(t, false);
        if (!rect || rect.width === 0) return;

        var pos    = layer.property("Anchor Point").value;
        var anchor = layer.property("Anchor Point").value;
        var scale  = layer.property("Scale").value;
        var sx     = scale[0] / 100;
        var sy     = scale[1] / 100;

        function ls2cs(lx, ly) {
            return [
                pos[0] + (lx - anchor[0]) * sx,
                pos[1] + (ly - anchor[1]) * sy
            ];
        }

        var r = rect;
        var topLeft   = ls2cs(r.left,            r.top);
        var topRight  = ls2cs(r.left + r.width,  r.top);
        var botLeft   = ls2cs(r.left,            r.top + r.height);
        var botRight  = ls2cs(r.left + r.width,  r.top + r.height);
        var topCenter = ls2cs(r.left + r.width * 0.5, r.top);
        var botCenter = ls2cs(r.left + r.width * 0.5, r.top + r.height);
        var center    = ls2cs(r.left + r.width * 0.5, r.top + r.height * 0.5);

        var fx = layer.property("ADBE Effect Parade") ||
                 layer.property("Effects") ||
                 layer.property(5);
        if (!fx || fx.numProperties === 0) return;

        for (var i = 1; i <= fx.numProperties; i++) {
            var effect = fx.property(i);
            var mn = "";
            try { mn = effect.matchName; } catch(e) { continue; }

            if (mn === "ADBE Ramp") {
                try { effect.property("Start of Ramp").setValue(topCenter); } catch(e) {}
                try { effect.property("End of Ramp").setValue(botCenter);   } catch(e) {}
            }

            if (mn === "ADBE 4-Color Gradient") {
                var grp = null;
                try { grp = effect.property("Positions & Colors"); }    catch(e1) {}
                if (!grp) {
                    try { grp = effect.property("ADBE 4ColorGradient-0001"); } catch(e2) {}
                }
                if (grp) {
                    try { grp.property("Point 1").setValue(topLeft);  } catch(e) {}
                    try { grp.property("Point 2").setValue(topRight); } catch(e) {}
                    try { grp.property("Point 3").setValue(botLeft);  } catch(e) {}
                    try { grp.property("Point 4").setValue(botRight); } catch(e) {}
                    try { grp.property("ADBE 4ColorGradient-0002").setValue(topLeft);  } catch(e) {}
                    try { grp.property("ADBE 4ColorGradient-0004").setValue(topRight); } catch(e) {}
                    try { grp.property("ADBE 4ColorGradient-0006").setValue(botLeft);  } catch(e) {}
                    try { grp.property("ADBE 4ColorGradient-0008").setValue(botRight); } catch(e) {}
                } else {
                    try { effect.property("Point 1").setValue(topLeft);  } catch(e) {}
                    try { effect.property("Point 2").setValue(topRight); } catch(e) {}
                    try { effect.property("Point 3").setValue(botLeft);  } catch(e) {}
                    try { effect.property("Point 4").setValue(botRight); } catch(e) {}
                }
            }

            if (mn === "CC Light Sweep") {
                try { effect.property("Center").setValue(center); } catch(e) {}
            }
        }
    } catch(e) {}
}

function enforceColorRevealGradient(layer) {
    // Color Reveal: top-left + top-right = blue, bottom-left + bottom-right = white.
    // AE's 4-Color Gradient color properties use the even match-name slots.
    try {
        var fx = layer.property("ADBE Effect Parade");
        if (!fx) return;
        var blue = [0.117647, 0.690196, 1.0]; // #1EB0FF-ish clean blue
        var white = [1.0, 1.0, 1.0];
        for (var i = 1; i <= fx.numProperties; i++) {
            var effect = fx.property(i);
            var mn = "";
            try { mn = effect.matchName; } catch(e) { continue; }
            if (mn !== "ADBE 4ColorGradient") continue;
            var grp = null;
            try { grp = effect.property("Positions & Colors"); } catch(e1) {}
            if (!grp) grp = effect;
            try { grp.property("ADBE 4ColorGradient-0002").setValue(blue); } catch(e) {}
            try { grp.property("ADBE 4ColorGradient-0004").setValue(blue); } catch(e) {}
            try { grp.property("ADBE 4ColorGradient-0006").setValue(white); } catch(e) {}
            try { grp.property("ADBE 4ColorGradient-0008").setValue(white); } catch(e) {}
            // Fallback for versions exposing display names.
            try { grp.property("Color 1").setValue(blue); } catch(e) {}
            try { grp.property("Color 2").setValue(blue); } catch(e) {}
            try { grp.property("Color 3").setValue(white); } catch(e) {}
            try { grp.property("Color 4").setValue(white); } catch(e) {}
        }
    } catch(e) {}
}

function applyPreset(pathStr) {
    undoWrapper("Apply Preset", function() {
        var comp = getActiveComp();
        if (!comp) return;
        
        var presetFile = new File(pathStr);
        if (!presetFile.exists) return alert("Preset file not found: " + pathStr);
        
        if (pathStr.toLowerCase().indexOf("animation enhancement") !== -1) {
            var selected = comp.selectedLayers;
            var layer = comp.layers.addShape();
            layer.name = "Animation Enhancement";
            
            // ── Selected layer ki EXACT length match karo ────────────────────
            if (selected && selected.length > 0) {
                var selIn  = selected[0].inPoint;
                var selOut = selected[0].outPoint;
                layer.startTime = selIn;
                layer.inPoint   = selIn;
                layer.outPoint  = selOut;
            } else {
                layer.startTime = 0;
                layer.inPoint   = 0;
                layer.outPoint  = comp.duration;
            }
            
            var shapeContents = layer.property("ADBE Root Vectors Group");
            var rect = shapeContents.addProperty("ADBE Vector Shape - Rect");
            rect.property("ADBE Vector Rect Size").setValue([comp.width, comp.height]);
            
            var fill = shapeContents.addProperty("ADBE Vector Graphic - Fill");
            fill.property("ADBE Vector Fill Color").setValue([1, 1, 1]);
            
            layer.adjustmentLayer = true;
            layer.applyPreset(presetFile);
            
            // ── Selected layer ke just UPAR rakho ────────────────────────────
            if (selected && selected.length > 0) {
                moveAboveSelected(layer, selected);
            }
        } else {
            var layers = comp.selectedLayers;
            if (layers.length === 0) return alert("Select a layer to apply preset.");
            
            for (var i = 0; i < layers.length; i++) {
                layers[i].applyPreset(presetFile);
                fixTextPresetEffectPoints(layers[i], comp);
                if (pathStr.toLowerCase().indexOf("color reveal.ffx") !== -1 || pathStr.toLowerCase().indexOf("color reveal") !== -1) {
                    enforceColorRevealGradient(layers[i]);
                }
            }
        }
    });
}

// ═══════════════════════════════════════════════════════════════════════════════
//  ENHANCE TOOLKIT — Rounded Corners + Bounce
// ═══════════════════════════════════════════════════════════════════════════════
function _dc_getEffectsGroup(layer) {
    if (!layer) return null;
    try { return layer.property("ADBE Effect Parade") || layer.property("Effects") || layer.property(5); } catch (e) { return null; }
}

function _dc_findEffectByName(effectsGroup, name) {
    if (!effectsGroup || !name) return null;
    try {
        for (var i = 1; i <= effectsGroup.numProperties; i++) {
            var fx = effectsGroup.property(i);
            if (fx && fx.name === name) return fx;
        }
    } catch (e) {}
    return null;
}

function _dc_getOrAddSliderControl(effectsGroup, name, value) {
    var fx = _dc_findEffectByName(effectsGroup, name);
    if (!fx) {
        try {
            fx = effectsGroup.addProperty("ADBE Slider Control");
            fx.name = name;
        } catch (eAdd) { return null; }
    }
    try {
        var slider = fx.property("Slider") || fx.property(1);
        if (slider) slider.setValue(value);
        return slider;
    } catch (eSet) { return null; }
}

function _dc_getOrAddCheckboxControl(effectsGroup, name, value) {
    var fx = _dc_findEffectByName(effectsGroup, name);
    if (!fx) {
        try {
            fx = effectsGroup.addProperty("ADBE Checkbox Control");
            fx.name = name;
        } catch (eAdd) { return null; }
    }
    try {
        var checkbox = fx.property("Checkbox") || fx.property(1);
        if (checkbox) checkbox.setValue(value ? 1 : 0);
        return checkbox;
    } catch (eSet) { return null; }
}

function _dc_isEffectProperty(prop) {
    try {
        var p = prop;
        while (p) {
            var mn = "";
            try { mn = p.matchName || ""; } catch (eMn) {}
            if (mn === "ADBE Effect Parade") return true;
            p = p.parentProperty;
        }
    } catch (e) {}
    return false;
}

function _dc_isBounceCompatibleProperty(prop) {
    if (!prop || !prop.canSetExpression) return false;
    try {
        if (_dc_isEffectProperty(prop)) return false;
        var t = prop.propertyValueType;
        // Expressions are meaningful for scalar/vector numeric properties.
        return t === PropertyValueType.OneD ||
               t === PropertyValueType.TwoD ||
               t === PropertyValueType.TwoD_SPATIAL ||
               t === PropertyValueType.ThreeD ||
               t === PropertyValueType.ThreeD_SPATIAL;
    } catch (e) { return false; }
}

function _dc_getBounceTarget(layer) {
    // Intelligent selection rule:
    // 1) Exactly one compatible property explicitly selected -> use it.
    // 2) Otherwise, if exactly one layer is selected, prefer the selected
    //    transform property (Position/Scale/Rotation) if AE reports it.
    // 3) Fall back to Position. Never attach the expression to text/color/audio
    //    properties that cannot participate in numeric overshoot math.
    try {
        var selectedProps = layer.selectedProperties || [];
        var compatible = [];
        for (var i = 0; i < selectedProps.length; i++) {
            if (_dc_isBounceCompatibleProperty(selectedProps[i])) compatible.push(selectedProps[i]);
        }
        if (compatible.length === 1) return compatible[0];
    } catch (eSelected) {}

    try {
        var tg = layer.property('ADBE Transform Group');
        var preferred = [
            tg ? tg.property('ADBE Position') : null,
            tg ? tg.property('ADBE Scale') : null,
            tg ? tg.property('ADBE Rotate Z') : null,
            tg ? tg.property('ADBE Opacity') : null
        ];
        // Position is the deterministic default, but use a selected transform
        // if AE exposes exactly one selected transform property.
        if (selectedProps && selectedProps.length) {
            for (var p = 0; p < preferred.length; p++) {
                if (preferred[p] && preferred[p].selected && _dc_isBounceCompatibleProperty(preferred[p])) return preferred[p];
            }
        }
        for (var q = 0; q < preferred.length; q++) {
            if (preferred[q] && preferred[q].matchName === 'ADBE Position' && _dc_isBounceCompatibleProperty(preferred[q])) return preferred[q];
        }
    } catch (eTransform) {}

    try {
        var pos = layer.property('Position');
        if (_dc_isBounceCompatibleProperty(pos)) return pos;
    } catch (ePos) {}
    return null;
}

function _dc_bounceExpression() {
    // Exact overshoot+ algorithm supplied by the user, adapted only so its
    // four controls are native Expression Controls on the selected layer.
    return 'try{' +
        'var amp=effect("DeepComp Bounce | Amplitude")("Slider")/1000;' +
        'var freq=effect("DeepComp Bounce | Frequency")("Slider");' +
        'var decay=effect("DeepComp Bounce | Decay")("Slider");' +
        'var floor=effect("DeepComp Bounce | Floor")("Checkbox");' +
        'var n,numkeys,v,t;' +
        'if(floor!=true){' +
            'n=0;' +
            'if(numKeys>0){n=nearestKey(time).index;if(key(n).time>time){n--;}};' +
            'if(n==0){t=0;}else{t=time-key(n).time;}' +
            'if(n>0){v=velocityAtTime(key(n).time-thisComp.frameDuration/10);value+v*amp*(Math.sin(freq*t*2*Math.PI)/Math.exp(decay*t));}else{value}' +
        '}else{' +
            'n=0;' +
            'if(numKeys>0){n=nearestKey(time).index;if(key(n).time>time){n--;}};' +
            'if(n==0){t=0;}else{t=time-key(n).time;}' +
            'if(n>0){v=velocityAtTime(key(n).time-thisComp.frameDuration/10);value+v*amp*-(Math.abs(Math.sin(freq*t*2*Math.PI))/Math.exp(decay*t));}else{value}' +
        '}' +
    '}catch(err){value}';
}

function applyDeepCompRoundedCorners(radius, borderValue) {
    var result = "error";
    undoWrapper("Rounded Corners", function() {
        try {
            var comp = getActiveComp();
            if (!comp) { result = "Open a composition first."; return; }
            var layers = comp.selectedLayers;
            if (!layers || layers.length === 0) { result = "Select a layer first."; return; }

            var r = Number(radius);
            if (!isFinite(r)) r = 0;
            r = Math.max(0, Math.min(100, r));

            var b = Number(borderValue);
            if (!isFinite(b)) b = Math.max(0, 40 + (r - 10) * 10);
            b = Math.max(0, b);

            for (var i = 0; i < layers.length; i++) {
                var layer = layers[i];
                var fxGroup = _dc_getEffectsGroup(layer);
                if (!fxGroup) continue;

                // Persist the radius on the layer so the border remains live-editable.
                var radiusSlider = _dc_getOrAddSliderControl(fxGroup, "DeepComp Corner Radius", r);
                if (!radiusSlider) { result = "Could not create the radius control on: " + layer.name; return; }

                var rounded = _dc_findEffectByName(fxGroup, "Rounded Edges");
                if (!rounded) rounded = _dc_findEffectByName(fxGroup, "Roughen Edges");
                if (!rounded) {
                    // AE exposes this native effect as Roughen Edges. We rename
                    // the instance to the user-facing “Rounded Edges” tool name
                    // used by DeepComp and by the supplied reference screenshot.
                    try { rounded = fxGroup.addProperty("ADBE Roughen Edges"); } catch (eMatch) {}
                    if (rounded) { try { rounded.name = "Rounded Edges"; } catch (eRenameRounded) {} }
                }
                if (!rounded) {
                    result = "After Effects could not create the Rounded Edges effect on: " + layer.name;
                    return;
                }

                var border = null;
                try { border = rounded.property("Border"); } catch (eBorderName) {}
                if (!border) {
                    try { border = rounded.property(3); } catch (eBorderIndex) {}
                }
                if (!border) {
                    result = "Rounded Edges was created, but its Border control was not found on: " + layer.name;
                    return;
                }

                // Border is formula-driven so changing DeepComp Corner Radius in AE
                // keeps the relationship alive. The panel also sends the evaluated value.
                var borderExpr = 'Math.max(0, 40 + (effect("DeepComp Corner Radius")("Slider") - 10) * 10);';
                try {
                    border.expression = borderExpr;
                    border.expressionEnabled = true;
                } catch (eExpr) {
                    // Fallback for older AE builds that do not accept an expression here.
                    border.setValue(b);
                }
            }
            result = "ok";
        } catch (e) {
            result = "Rounded Corners failed: " + e.toString();
        }
    });
    return result;
}

function applyDeepCompBounce(amplitude, frequency, decay, floor) {
    var result = "error";
    undoWrapper("Bounce", function() {
        try {
            var comp = getActiveComp();
            if (!comp) { result = "Open a composition first."; return; }
            var layers = comp.selectedLayers;
            if (!layers || layers.length === 0) { result = "Select a layer first."; return; }

            var a = Number(amplitude); if (!isFinite(a)) a = 250; a = Math.max(0, Math.min(2000, a));
            var f = Number(frequency); if (!isFinite(f)) f = 3;   f = Math.max(0.1, Math.min(20, f));
            var d = Number(decay);    if (!isFinite(d)) d = 5;    d = Math.max(0.1, Math.min(20, d));
            var fl = !!floor;
            var expr = _dc_bounceExpression();

            for (var i = 0; i < layers.length; i++) {
                var layer = layers[i];
                var fxGroup = _dc_getEffectsGroup(layer);
                if (!fxGroup) continue;

                _dc_getOrAddSliderControl(fxGroup, "DeepComp Bounce | Amplitude", a);
                _dc_getOrAddSliderControl(fxGroup, "DeepComp Bounce | Frequency", f);
                _dc_getOrAddSliderControl(fxGroup, "DeepComp Bounce | Decay", d);
                _dc_getOrAddCheckboxControl(fxGroup, "DeepComp Bounce | Floor", fl);

                var target = _dc_getBounceTarget(layer);
                if (!target) {
                    result = "No expression-capable property found on: " + layer.name;
                    return;
                }

                try {
                    target.expression = expr;
                    target.expressionEnabled = true;
                } catch (eExpression) {
                    result = "Could not apply Bounce to " + layer.name + ": " + eExpression.toString();
                    return;
                }
            }
            result = "ok";
        } catch (e) {
            result = "Bounce failed: " + e.toString();
        }
    });
    return result;
}

// ─── COMPREHENSIVE EFFECT MATCH-NAME LOOKUP ─────────────────────────────────
function getEffectMatchName(displayName) {
    var lookup = {
        // ── Blur & Sharpen ──
        "Bilateral Blur":           "ADBE Bilateral Blur",
        "Box Blur":                 "ADBE Box Blur2",
        "Camera Lens Blur":         "ADBE Camera Lens Blur",
        "Camera-Shake Deblur":      "ADBE CameraShakeDeblur",
        "CC Cross Blur":            "CC Cross Blur",
        "CC Radial Blur":           "CC Radial Blur",
        "CC Radial Fast Blur":      "CC Radial Fast Blur",
        "CC Vector Blur":           "CC Vector Blur",
        "Channel Blur":             "ADBE Channel Blur",
        "Compound Blur":            "ADBE Compound Blur",
        "Directional Blur":         "ADBE Motion Blur",
        "Fast Box Blur":            "ADBE Fast Box Blur",
        "Gaussian Blur":            "ADBE Gaussian Blur 2",
        "Lens Blur":                "ADBE Lens Blur",
        "Radial Blur":              "ADBE Radial Blur",
        "Reduce Interlace Flicker": "ADBE Reduce Interlace Flicker",
        "Sharpen":                  "ADBE Sharpen",
        "Smart Blur":               "ADBE Smart Blur",
        "Unsharp Mask":             "ADBE Unsharp Mask",
        // ── Channel ──
        "Arithmetic":               "ADBE Arithmetic",
        "Blend":                    "ADBE Blend",
        "Calculations":             "ADBE Calculations",
        "CC Composite":             "CC Composite",
        "Channel Combiner":         "ADBE Channel Combiner",
        "Compound Arithmetic":      "ADBE Compound Arithmetic",
        "Invert":                   "ADBE Invert",
        "Minimax":                  "ADBE Minimax",
        "Remove Color Matting":     "ADBE Remove Color Matting",
        "Set Channels":             "ADBE Set Channels",
        "Set Matte":                "ADBE Set Matte",
        "Shift Channels":           "ADBE Shift Channels",
        "Solid Composite":          "ADBE Solid Composite",
        // ── Color Correction ──
        "Auto Color":               "ADBE Auto Color",
        "Auto Contrast":            "ADBE Auto Contrast",
        "Auto Levels":              "ADBE Auto Levels",
        "Black & White":            "ADBE Black&White",
        "Brightness & Contrast":    "ADBE Brightness & Contrast 2",
        "Broadcast Colors":         "ADBE Broadcast Colors",
        "CC Color Neutralizer":     "CC Color Neutralizer",
        "CC Color Offset":          "CC Color Offset",
        "CC Kernel":                "CC Kernel",
        "CC Toner":                 "CC Toner",
        "Change Color":             "ADBE Change Color",
        "Change to Color":          "ADBE Change To Color",
        "Channel Mixer":            "ADBE Channel Mixer",
        "Color Balance":            "ADBE Color Balance",
        "Color Balance (HLS)":      "ADBE Color Balance (HLS)",
        "Color Link":               "ADBE Color Link",
        "Color Stabilizer":         "ADBE Color Stabilizer",
        "Colorama":                 "ADBE Colorama",
        "Curves":                   "ADBE CurvesCustom",
        "Equalize":                 "ADBE Equalize",
        "Exposure":                 "ADBE Exposure",
        "Gamma/Pedestal/Gain":      "ADBE Gamma/Pedestal/Gain",
        "Hue/Saturation":           "ADBE HUE SATURATION",
        "Hue/Sat":                  "ADBE HUE SATURATION",
        "Leave Color":              "ADBE Leave Color",
        "Levels":                   "ADBE Levels",
        "Levels (Individual Controls)": "ADBE Levels2",
        "Lumetri Color":            "ADBE Lumetri",
        "Photo Filter":             "ADBE Photo Filter",
        "PS Arbitrary Map":         "ADBE PS Arbitrary Map",
        "Selective Color":          "ADBE Selective Color",
        "Shadow/Highlight":         "ADBE Shadow-Highlight",
        "Tint":                     "ADBE Tint",
        "Tritone":                  "ADBE Tritone",
        "Vibrance":                 "ADBE Vibrance",
        // ── Distort ──
        "Bezier Warp":              "ADBE Bezier Warp",
        "Bulge":                    "ADBE Bulge",
        "CC Bend It":               "CC Bend It",
        "CC Blobylize":             "CC Blobylize",
        "CC Flo Motion":            "CC Flo Motion",
        "CC Griddler":              "CC Griddler",
        "CC Lens":                  "CC Lens",
        "CC Page Turn":             "CC Page Turn",
        "CC Power Pin":             "CC Power Pin",
        "CC Ripple Pulse":          "CC Ripple Pulse",
        "CC Slant":                 "CC Slant",
        "CC Smear":                 "CC Smear",
        "CC Split":                 "CC Split",
        "CC Split 2":               "CC Split 2",
        "CC Tiler":                 "CC Tiler",
        "Corner Pin":               "ADBE Corner Pin",
        "Displacement Map":         "ADBE Displacement Map",
        "Liquify":                  "ADBE FreePin3",
        "Magnify":                  "ADBE Magnify",
        "Mesh Warp":                "ADBE Mesh Warp",
        "Mirror":                   "ADBE Mirror",
        "Offset":                   "ADBE Shift Channels2",
        "Optics Compensation":      "ADBE Optics Compensation",
        "Polar Coordinates":        "ADBE Polar Coordinates",
        "Reshape":                  "ADBE Reshape",
        "Ripple":                   "ADBE Ripple",
        "Rolling Shutter Repair":   "ADBE Rolling Shutter",
        "Smear":                    "ADBE Smear",
        "Spherize":                 "ADBE Spherize",
        "Transform":                "ADBE Geometry2",
        "Turbulent Displace":       "ADBE Turbulent Displace",
        "Twirl":                    "ADBE Twirl",
        "Warp":                     "ADBE Warp",
        "Warp Stabilizer VFX":      "ADBE Warp Stabilizer2",
        "Wave Warp":                "ADBE Wave Warp",
        "Motion Tile":              "ADBE Motion Tile",
        // ── Generate ──
        "4-Color Gradient":         "ADBE 4-Color Gradient",
        "Advanced Lightning":       "ADBE ADBEAdvancedLightning",
        "Audio Spectrum":           "ADBE AudioSpectrum",
        "Audio Waveform":           "ADBE AudioWaveform",
        "Beam":                     "ADBE Beam",
        "CC Glue Gun":              "CC Glue Gun",
        "CC Light Burst 2.5":       "CC Light Burst 2.5",
        "CC Light Rays":            "CC Light Rays",
        "CC Light Sweep":           "CC Light Sweep",
        "CC Thread":                "CC Thread",
        "Cell Pattern":             "ADBE Cell Pattern",
        "Checkerboard":             "ADBE Checkerboard",
        "Circle":                   "ADBE Circle",
        "Ellipse":                  "ADBE Ellipse",
        "Eyedropper Fill":          "ADBE Eyedropper Fill",
        "Fill":                     "ADBE Fill",
        "Fractal":                  "ADBE Fractal",
        "Gradient Ramp":            "ADBE Ramp",
        "Grid":                     "ADBE Grid",
        "Lens Flare":               "ADBE Lens Flare",
        "Lightning":                "ADBE Lightning",
        "Paint Bucket":             "ADBE Paint Bucket",
        "Radio Waves":              "ADBE Radio Waves",
        "Scribble":                 "ADBE Scribble",
        "Stroke":                   "ADBE Stroke",
        "Vegas":                    "ADBE Vegas",
        "Write-on":                 "ADBE Write-on",
        // ── Keying ──
        "CC Simple Wire Removal":   "CC Simple Wire Removal",
        "Color Difference Key":     "ADBE Color Difference Key",
        "Color Range":              "ADBE Color Range",
        "Difference Matte":         "ADBE Difference Matte",
        "Extract":                  "ADBE Extract",
        "Inner/Outer Key":          "ADBE Inner/Outer Key",
        "Key Cleaner":              "ADBE Key Cleaner",
        "Keylight (1.2)":           "ADBE Keylight",
        "Keylight":                 "ADBE Keylight",
        "Linear Color Key":         "ADBE Linear Color Key",
        "Luma Key":                 "ADBE Luma Key",
        "Spill Suppressor":         "ADBE Spill Suppressor",
        // ── Matte ──
        "Matte Choker":             "ADBE Matte Choker",
        "Refine Hard Matte":        "ADBE Refine Hard Matte",
        "Refine Soft Matte":        "ADBE Refine Soft Matte",
        "Simple Choker":            "ADBE Simple Choker",
        // ── Noise & Grain ──
        "Add Grain":                "ADBE Add Grain",
        "Dust & Scratches":         "ADBE Dust & Scratches",
        "Fractal Noise":            "ADBE Fractal Noise",
        "Match Grain":              "ADBE Match Grain",
        "Median":                   "ADBE Median3",
        "Noise":                    "ADBE Noise",
        "Noise Alpha":              "ADBE Noise Alpha",
        "Noise HLS":                "ADBE Noise HLS",
        "Noise HLS Auto":           "ADBE Noise HLS Auto",
        "Remove Grain":             "ADBE Remove Grain",
        "Turbulent Noise":          "ADBE Turbulent Noise",
        // ── Perspective ──
        "3D Camera Tracker":        "ADBE CAMERATRACKER",
        "Bevel Alpha":              "ADBE Bevel Alpha",
        "Bevel Edges":              "ADBE Bevel Edges",
        "CC Cylinder":              "CC Cylinder",
        "CC Environment":           "CC Environment",
        "CC Sphere":                "CC Sphere",
        "CC Spotlight":             "CC Spotlight",
        "Drop Shadow":              "ADBE Drop Shadow",
        "Radial Shadow":            "ADBE Radial Shadow",
        // ── Simulation ──
        "Card Dance":               "ADBE Card Dance",
        "Caustics":                 "ADBE Caustics",
        "CC Ball Action":           "CC Ball Action",
        "CC Bubbles":               "CC Bubbles",
        "CC Drizzle":               "CC Drizzle",
        "CC Hair":                  "CC Hair",
        "CC Mr. Mercury":           "CC Mr. Mercury",
        "CC Particle Systems II":   "CC Particle Systems II",
        "CC Particle World":        "CC Particle World",
        "CC Pixel Polly":           "CC Pixel Polly",
        "CC Rainfall":              "CC Rainfall",
        "CC Scatterize":            "CC Scatterize",
        "CC Snowfall":              "CC Snowfall",
        "CC Star Burst":            "CC Star Burst",
        "Foam":                     "ADBE Foam",
        "Particle Playground":      "ADBE Particle Playground",
        "Shatter":                  "ADBE Shatter",
        "Wave World":               "ADBE Wave World",
        // ── Stylize ──
        "Brush Strokes":            "ADBE Brush Strokes",
        "Cartoon":                  "ADBE Cartoon",
        "CC Block Load":            "CC Block Load",
        "CC Burn Film":             "CC Burn Film",
        "CC Glass":                 "CC Glass",
        "CC HexTile":               "CC HexTile",
        "CC Kaleida":               "CC Kaleida",
        "CC Mr. Smoothie":          "CC Mr. Smoothie",
        "CC Plastic":               "CC Plastic",
        "CC RepeTile":              "CC RepeTile",
        "CC Threshold":             "CC Threshold",
        "CC Threshold RGB":         "CC Threshold RGB",
        "CC Vignette":              "CC Vignette",
        "Color Emboss":             "ADBE Color Emboss",
        "Emboss":                   "ADBE Emboss",
        "Find Edges":               "ADBE Find Edges",
        "Glow":                     "ADBE Glow",
        "Mosaic":                   "ADBE Mosaic",
        "Motion Blur":              "ADBE Motion Blur",
        "Posterize":                "ADBE Posterize",
        "Roughen Edges":            "ADBE Roughen Edges",
        "Scatter":                  "ADBE Scatter",
        "Strobe Light":             "ADBE Strobe Light",
        "Texturize":                "ADBE Texturize",
        "Threshold":                "ADBE Threshold",
        // ── Text ──
        "Numbers":                  "ADBE Numbers",
        "Timecode":                 "ADBE Timecode",
        // ── Time ──
        "CC Force Motion Blur":     "CC Force Motion Blur",
        "CC Wide Time":             "CC Wide Time",
        "Echo":                     "ADBE Echo",
        "Posterize Time":           "ADBE Posterize Time",
        "Time Difference":          "ADBE Time Difference",
        "Time Displacement":        "ADBE Time Displacement",
        "Timewarp":                 "ADBE Timewarp",
        // ── Transition ──
        "Block Dissolve":           "ADBE Block Dissolve",
        "Card Wipe":                "ADBE Card Wipe",
        "CC Glass Wipe":            "CC Glass Wipe",
        "CC Grid Wipe":             "CC Grid Wipe",
        "CC Image Wipe":            "CC Image Wipe",
        "CC Jaws":                  "CC Jaws",
        "CC Light Wipe":            "CC Light Wipe",
        "CC Line Sweep":            "CC Line Sweep",
        "CC Radial ScaleWipe":      "CC Radial ScaleWipe",
        "CC Scale Wipe":            "CC Scale Wipe",
        "CC Twister":               "CC Twister",
        "CC WarpoMatic":            "CC WarpoMatic",
        "Gradient Wipe":            "ADBE Gradient Wipe",
        "Iris Wipe":                "ADBE Iris Wipe",
        "Linear Wipe":              "ADBE Linear Wipe",
        "Radial Wipe":              "ADBE Radial Wipe",
        "Venetian Blinds":          "ADBE Venetian Blinds",
        // ── Utility ──
        "Apply Color LUT":          "ADBE Apply Color LUT2",
        "Cineon Converter":         "ADBE Cineon Converter",
        "Color Profile Converter":  "ADBE Color Profile Converter",
        "Grow Bounds":              "ADBE Grow Bounds",
        "HDR Compander":            "ADBE HDR Compander",
        "HDR Highlight Compression":"ADBE HDR Highlight Compression",
        "Depth Matte":              "ADBE Depth Matte",
        "Depth of Field":           "ADBE Depth of Field",
        "High-Low Pass":            "ADBE High-Low Pass",
        // ── Popular Third-Party Plugins ──
        "Deep Glow":                "Deep Glow",
        "Shadow Studio 2":          "Shadow Studio 2",
        "Shadow Studio 3":          "Shadow Studio 3",
        "Saber":                    "Saber",
        "RSMB":                     "RSMB",
        "RSMB Pro":                 "RSMB Pro",
        "Twixtor":                  "Twixtor",
        "Twixtor Pro":              "Twixtor Pro",
        "Particular":               "Particular",
        "Trapcode Particular":      "Particular",
        "Form":                     "Form",
        "Trapcode Form":            "Form",
        "Mir":                      "Mir",
        "Trapcode Mir":             "Mir",
        "Element 3D":               "Element 3D",
        "Video Copilot Element 3D": "Element 3D",
        "Optical Flares":           "Optical Flares",
        "Orb":                      "Orb",
        "VC Orb":                   "Orb",
        "Mettle SkyBox":            "Mettle SkyBox Studio",
        "BCC Lens Flare":           "BCC Lens Flare",
        "BCC Glitter":              "BCC Glitter",
        "BCC Motion Blur":          "BCC Motion Blur",
        "BCC Fast Film Glow":       "BCC Fast Film Glow",
        "BCC Chromatic Aberration": "BCC Chromatic Aberration",
        "BCC Rays":                 "BCC Rays",
        "Sapphire Glow":            "S_Glow",
        "Sapphire Blur":            "S_Blur",
        "Sapphire Flare":           "S_LensFlare",
        "Sapphire Grain":           "S_Grain",
        "Sapphire Vignette":        "S_Vignette",
        "Sapphire Rays":            "S_Rays",
        "Sapphire WarpDrops":       "S_WarpDrops",
        "Mocha AE":                 "ADBE Mocha Shape",
        "Magic Bullet Looks":       "Magic Bullet Looks",
        "Magic Bullet Colorista":   "Colorista IV",
        "Neat Video":               "Neat Video v5 AE",
        "Denoiser III":             "Denoiser III",
        "Film Convert":             "FilmConvert",
        "Universe Glow":            "Universe Glow",
        "Universe Chromatic Aberration": "Universe Chromatic Aberration",
        "Universe VHS":             "Universe VHS",
        "Universe Kaleidoscope":    "Universe Kaleidoscope",
        "ReelSmart Motion Blur":    "RSMB",
        "Sure Target 2":            "Sure Target 2",
        "Starglow":                 "Starglow",
        "Shine":                    "Shine",
        "3D Stroke":                "3D Stroke",
        "Lux":                      "Lux",
        "Sound Keys":               "Sound Keys"
    };
    
    var found = lookup[displayName];
    return found ? found : displayName;
}

// ─── SMART APPLY EFFECT ──────────────────────────────────────────────────────
function applyEffect(effectName) {
    undoWrapper("Apply Effect: " + effectName, function() {
        var comp = getActiveComp();
        if (!comp) return;
        var layers = comp.selectedLayers;
        if (layers.length === 0) return alert("Please select a layer first, then click the effect.");
        
        var matchName = getEffectMatchName(effectName);
        
        for (var i = 0; i < layers.length; i++) {
            var layer = layers[i];
            var effectsGroup = layer.property("ADBE Effect Parade") ||
                               layer.property("Effects") ||
                               layer.property(5);
            if (!effectsGroup) continue;
            
            var applied = false;
            try { effectsGroup.addProperty(matchName); applied = true; } catch(e1) {}
            if (!applied && matchName !== effectName) {
                try { effectsGroup.addProperty(effectName); applied = true; } catch(e2) {}
            }
            if (!applied) {
                try { var dummy = effectsGroup.addProperty(effectName.toLowerCase()); applied = true; } catch(e3) {}
            }
            if (!applied) {
                alert(
                    "Effect \"" + effectName + "\" could not be applied.\n\n" +
                    "Possible reasons:\n" +
                    "1. Plugin is not installed on this machine.\n" +
                    "2. Effect name spelling is slightly different.\n" +
                    "3. The layer type does not support this effect."
                );
            }
        }
    });
}

// ─── ZOOM IN ─────────────────────────────────────────────────────────────────
// Selected layer ke shuru mein 1 second ki zoom in layer, just UPAR
function applySmoothZoomIn() {
    undoWrapper("Smooth Zoom In", function() {
        var comp = getActiveComp();
        if (!comp) return;
        
        var duration = 1.0;
        var selected = comp.selectedLayers;
        
        var compStart, compEnd;
        if (selected && selected.length > 0) {
            compStart = selected[0].inPoint;
            compEnd   = compStart + duration;
        } else {
            compStart = comp.time;
            compEnd   = comp.time + duration;
        }
        
        var layer = comp.layers.addShape();
        layer.name = "deepcomp zoom in";
        layer.startTime = compStart;
        layer.inPoint   = compStart;
        layer.outPoint  = compEnd;
        
        var shapeContents = layer.property("ADBE Root Vectors Group");
        var rect = shapeContents.addProperty("ADBE Vector Shape - Rect");
        rect.property("ADBE Vector Rect Size").setValue([comp.width, comp.height]);
        
        var fill = shapeContents.addProperty("ADBE Vector Graphic - Fill");
        fill.property("ADBE Vector Fill Color").setValue([1, 1, 1]);
        
        layer.adjustmentLayer = true;
        layer.motionBlur = true;
        comp.motionBlur = true;
        
        var effectsGroup = layer.property("ADBE Effect Parade") || layer.property("Effects") || layer.property(5);
        var transformEffect = null;
        try {
            transformEffect = effectsGroup.addProperty("ADBE Geometry2");
        } catch(e) {
            transformEffect = effectsGroup.addProperty("Transform");
        }
        
        var scale = transformEffect.property("Scale") || transformEffect.property("ADBE Geometry2-0004");
        scale.setValueAtTime(compStart, 100);
        scale.setValueAtTime(compEnd,   135);
        
        var easeIn = new KeyframeEase(0, 80);
        var easeOut = new KeyframeEase(0, 80);
        scale.setTemporalEaseAtKey(1, [easeIn], [easeOut]);
        scale.setTemporalEaseAtKey(2, [easeIn], [easeOut]);
        
        // ── Selected layer ke just UPAR rakho ────────────────────────────────
        if (selected && selected.length > 0) {
            moveAboveSelected(layer, selected);
        }
    });
}

// ─── ZOOM OUT ────────────────────────────────────────────────────────────────
// Selected layer ke end mein 1 second ki zoom out layer, just UPAR
function applySmoothZoomOut() {
    undoWrapper("Smooth Zoom Out", function() {
        var comp = getActiveComp();
        if (!comp) return;
        
        var duration = 1.0;
        var selected = comp.selectedLayers;
        
        var compStart, compEnd;
        if (selected && selected.length > 0) {
            compEnd   = selected[0].outPoint;
            compStart = compEnd - duration;
        } else {
            compEnd   = comp.time + duration;
            compStart = comp.time;
        }
        
        var layer = comp.layers.addShape();
        layer.name = "deepcomp zoom out";
        layer.startTime = compStart;
        layer.inPoint   = compStart;
        layer.outPoint  = compEnd;
        
        var shapeContents = layer.property("ADBE Root Vectors Group");
        var rect = shapeContents.addProperty("ADBE Vector Shape - Rect");
        rect.property("ADBE Vector Rect Size").setValue([comp.width, comp.height]);
        
        var fill = shapeContents.addProperty("ADBE Vector Graphic - Fill");
        fill.property("ADBE Vector Fill Color").setValue([1, 1, 1]);
        
        layer.adjustmentLayer = true;
        layer.motionBlur = true;
        comp.motionBlur = true;
        
        var effectsGroup = layer.property("ADBE Effect Parade") || layer.property("Effects") || layer.property(5);
        var transformEffect = null;
        try {
            transformEffect = effectsGroup.addProperty("ADBE Geometry2");
        } catch(e) {
            transformEffect = effectsGroup.addProperty("Transform");
        }
        
        var scale = transformEffect.property("Scale") || transformEffect.property("ADBE Geometry2-0004");
        scale.setValueAtTime(compStart, 135);
        scale.setValueAtTime(compEnd,   100);
        
        var easeIn = new KeyframeEase(0, 80);
        var easeOut = new KeyframeEase(0, 80);
        scale.setTemporalEaseAtKey(1, [easeIn], [easeOut]);
        scale.setTemporalEaseAtKey(2, [easeIn], [easeOut]);
        
        // ── Selected layer ke just UPAR rakho ────────────────────────────────
        if (selected && selected.length > 0) {
            moveAboveSelected(layer, selected);
        }
    });
}

function organiseProject() {
    undoWrapper("Organise Project", function() {
        var proj = app.project;
        var items = proj.items;
        
        var folderPng = null;
        var folderSfx = null;
        var folderComps = null;
        
        for (var i = 1; i <= items.length; i++) {
            if (items[i] instanceof FolderItem) {
                if (items[i].name == "PNG") folderPng = items[i];
                if (items[i].name == "SFX") folderSfx = items[i];
                if (items[i].name == "Comps") folderComps = items[i];
            }
        }
        
        if (!folderPng) folderPng = proj.items.addFolder("PNG");
        if (!folderSfx) folderSfx = proj.items.addFolder("SFX");
        if (!folderComps) folderComps = proj.items.addFolder("Comps");
        
        for (var i = 1; i <= items.length; i++) {
            var item = items[i];
            if (item.parentFolder.name != proj.rootFolder.name) continue;
            
            if (item instanceof CompItem) {
                item.parentFolder = folderComps;
            } else if (item instanceof FootageItem) {
                var ext = item.file ? item.file.name.split('.').pop().toLowerCase() : "";
                if (ext == "png" || ext == "jpg" || ext == "jpeg") {
                    item.parentFolder = folderPng;
                } else if (ext == "wav" || ext == "mp3") {
                    item.parentFolder = folderSfx;
                }
            }
        }
    });
}

function timeToSeconds(timeStr) {
    if (!timeStr) return 0;
    var cleanStr = timeStr.replace(/^\s+|\s+$/g, '').replace(",", ".");
    var parts = cleanStr.split(":");
    if (parts.length < 3) return 0;
    var hours = parseFloat(parts[0]) || 0;
    var minutes = parseFloat(parts[1]) || 0;
    var seconds = parseFloat(parts[2]) || 0;
    return (hours * 3600) + (minutes * 60) + seconds;
}

function importSRT() {
    var comp = getActiveComp();
    if (!comp) return "error";
    
    var srtFile = File.openDialog("Select SRT Subtitle File", "SRT files:*.srt");
    if (!srtFile) return "cancel";
    
    var count = 0;
    undoWrapper("Import SRT Subtitles", function() {
        srtFile.open("r");
        var content = srtFile.read();
        srtFile.close();
        
        var blocks = content.replace(/\r\n/g, "\n").split(/\n\s*\n/);
        
        for (var i = 0; i < blocks.length; i++) {
            var block = blocks[i].replace(/^\s+|\s+$/g, '');
            if (block === "") continue;
            
            var lines = block.split("\n");
            if (lines.length < 3) continue;
            
            var timeLine = lines[1];
            var times = timeLine.split("-->");
            if (times.length < 2) continue;
            
            var startSec = timeToSeconds(times[0]);
            var endSec = timeToSeconds(times[1]);
            
            var textLines = [];
            for (var j = 2; j < lines.length; j++) {
                textLines.push(lines[j]);
            }
            var textStr = textLines.join("\n");
            
            var textLayer = comp.layers.addText(textStr);
            textLayer.name = "Sub: " + textStr.replace(/\n/g, " ").substring(0, 15);
            textLayer.inPoint = startSec;
            textLayer.outPoint = endSec;
            
            var textProp = textLayer.property("Source Text");
            var textDoc = textProp.value;
            textDoc.justification = ParagraphJustification.CENTER_JUSTIFY;
            textProp.setValue(textDoc);
            
            textLayer.property("Position").setValue([comp.width / 2, comp.height * 0.85, 0]);
            count++;
        }
    });
    
    alert("Successfully imported " + count + " subtitles!");
    return count.toString();
}

function getExtensionLibraryRoot(extRootFromJS) {
    if (extRootFromJS && extRootFromJS !== "" && extRootFromJS !== "undefined") {
        return extRootFromJS;
    }
    try {
        var f = new File($.fileName);
        if (f.exists) {
            var candidate = f.parent.parent.fsName;
            var csxs = new Folder(candidate + (($.os.indexOf("Win") !== -1) ? "\\" : "/") + "CSXS");
            if (csxs.exists) return candidate;
        }
    } catch(e) {}
    return null;
}

// ─── GET USER-WRITABLE LIBRARY ROOT ─────────────────────────────────────────
function getUserLibraryRoot() {
    // Match main.js exactly. Folder.userData is not a portable HOME path on
    // every CEP/ExtendScript host, so use APPDATA/HOME environment variables.
    var isWin = ($.os.indexOf('Win') !== -1);
    var sep = isWin ? "\\" : "/";
    var base = isWin ? $.getenv('APPDATA') : $.getenv('HOME');
    if (!base || base === '') {
        // Conservative fallback for hosts that do not expose the environment.
        base = Folder.userData.fsName;
        if (!isWin) {
            var prefs = base;
            var needle = "/Library/Preferences";
            if (prefs.indexOf(needle) !== -1) base = prefs.substring(0, prefs.indexOf(needle));
        }
    }
    base = String(base).replace(/[\\\/]+$/, '');
    var libRoot = isWin
        ? base + sep + 'DeepComp' + sep + 'yugz.fx'
        : base + sep + 'Library' + sep + 'Application Support' + sep + 'DeepComp' + sep + 'yugz.fx';
    var libFolder = new Folder(libRoot);
    if (!libFolder.exists) libFolder.create();
    return libRoot;
}

// ─── SAVE PRECOMP ────────────────────────────────────────────────────────────
// Timeline-first Save Pre-comp system.
//
// Workflow:
//   1) Detect the selected pre-comp layer in the active timeline.
//   2) Use that layer's source CompItem as the asset to save.
//   3) Create a temporary project snapshot, reduce it to the source comp,
//      relink all file footage into the library's Assets folder, and save AEP.
//   4) Render the exact FIRST FRAME (time 0) to thumbnail.png.
//   5) Restore the user's original project snapshot.
//
// The operation never modifies the user's live project intentionally.  All
// destructive project operations happen only after a temporary backup exists.

function _dc_jsonEscape(str) {
    str = (str === null || str === undefined) ? "" : String(str);
    return str.replace(/\\/g, "\\\\").replace(/"/g, '\\"').replace(/\r/g, "\\r").replace(/\n/g, "\\n");
}

function _dc_sanitizeFileName(name) {
    name = (name === null || name === undefined) ? "Precomp" : String(name);
    name = name.replace(/[<>:"\\/\\|\\?\\*]/g, "_");
    name = name.replace(/[\\. ]+$/g, "");
    if (!name) name = "Precomp";
    return name.substring(0, 120);
}

function _dc_getSelectedPrecompInfo() {
    var out = {
        ok: false,
        name: "",
        sourceName: "",
        layerIndex: 0,
        compName: "",
        message: "No pre-comp layer selected."
    };
    try {
        var comp = app.project.activeItem;
        if (!comp || !(comp instanceof CompItem)) {
            out.message = "Open a composition and select a pre-comp layer.";
            return out;
        }
        var layers = comp.selectedLayers;
        if (!layers || layers.length !== 1) {
            out.message = layers && layers.length > 1
                ? "Select exactly one pre-comp layer."
                : "Select a pre-comp layer in the timeline.";
            return out;
        }
        var layer = layers[0];
        if (!(layer.source instanceof CompItem)) {
            out.message = "The selected layer is not a pre-comp.";
            return out;
        }
        if (!(layer.source instanceof CompItem) || !layer.source) {
            out.message = "The selected pre-comp has no valid source composition.";
            return out;
        }
        out.ok = true;
        out.name = layer.name || layer.source.name || "Precomp";
        out.sourceName = layer.source.name || out.name;
        out.layerIndex = layer.index || 0;
        out.compName = comp.name || "Composition";
        out.message = "Ready to save: " + out.sourceName;
    } catch (e) {
        out.message = "Could not inspect selection: " + e.toString();
    }
    return out;
}

function getSelectedPrecompInfo() {
    try {
        return JSON.stringify(_dc_getSelectedPrecompInfo());
    } catch (e) {
        return JSON.stringify({ ok:false, message:"Selection check failed." });
    }
}

function _dc_collectAndRelinkFootage(reducedComp, assetsFolder, sep) {
    // Run AFTER reduceProject, because that gives us the exact dependency set.
    var copied = 0;
    var failed = 0;
    var usedNames = {};

    function uniqueAssetName(originalName) {
        var base = originalName || "asset";
        var clean = _dc_sanitizeFileName(base);
        if (!usedNames[clean.toLowerCase()]) {
            usedNames[clean.toLowerCase()] = true;
            return clean;
        }
        var dot = clean.lastIndexOf(".");
        var stem = dot > 0 ? clean.substring(0, dot) : clean;
        var ext = dot > 0 ? clean.substring(dot) : "";
        var n = 2;
        while (usedNames[(stem + "_" + n + ext).toLowerCase()]) n++;
        var result = stem + "_" + n + ext;
        usedNames[result.toLowerCase()] = true;
        return result;
    }

    try {
        // FootageItem collection is safer than walking layers and avoids
        // duplicate copies when the same source is used multiple times.
        for (var i = 1; i <= app.project.numItems; i++) {
            var item = app.project.item(i);
            if (!(item instanceof FootageItem)) continue;
            if (!item.file || !item.file.exists) continue;

            var src = item.file;
            var destName = uniqueAssetName(src.name);
            var dest = new File(assetsFolder.fsName + sep + destName);
            try {
                // Refresh the library copy on every save; never silently reuse
                // an older asset with the same filename.
                if (dest.exists) { try { dest.remove(); } catch (eRemoveAsset) {} }
                src.copy(dest);
                if (dest.exists && dest.length > 0) {
                    // Relink the reduced project's footage to its self-contained asset.
                    item.replace(dest);
                    copied++;
                } else {
                    failed++;
                }
            } catch (eCopy) {
                failed++;
            }
        }
    } catch (eScan) {
        failed++;
    }

    return { copied: copied, failed: failed };
}

function _dc_renderFirstFrame(comp, thumbFile, sep) {
    var rendered = false;
    // The first visual frame is the composition's display start time, which is
    // not necessarily 0 on modern AE projects. Fall back to 0 on old hosts.
    var firstFrameTime = 0;
    try { if (isFinite(comp.displayStartTime)) firstFrameTime = Number(comp.displayStartTime); } catch (eStartTime) {}
    var frameDuration = 1.0 / (comp.frameRate || 30);
    try { frameDuration = comp.frameDuration || frameDuration; } catch (eFD) {}

    try { comp.time = firstFrameTime; } catch (eTime) {}

    // Preferred API. saveFrameToPng is an available AE scripting method (it is
    // still treated as an undocumented API by Adobe's community docs), and it
    // avoids touching the render queue at all.
    if (typeof comp.saveFrameToPng === 'function') {
        try {
            comp.saveFrameToPng(firstFrameTime, thumbFile);
            rendered = thumbFile.exists && thumbFile.length > 0;
        } catch (eDirect) {}
    }

    // Deterministic Render Queue fallback for hosts without saveFrameToPng.
    // OutputModule format is selected via an existing PNG output-module
    // template; simply setting a "Format" key is not portable across AE.
    if (!rendered) {
        var rqi = null;
        try {
            var rq = app.project.renderQueue;
            rqi = rq.items.add(comp);

            var om = rqi.outputModule(1);
            var templates = om.templates || [];
            var pngTemplate = null;
            for (var ti = 0; ti < templates.length; ti++) {
                var tname = String(templates[ti]);
                if (/png.*sequence|sequence.*png/i.test(tname)) { pngTemplate = tname; break; }
            }
            if (!pngTemplate) {
                for (var ti2 = 0; ti2 < templates.length; ti2++) {
                    if (/png/i.test(String(templates[ti2]))) { pngTemplate = String(templates[ti2]); break; }
                }
            }
            if (!pngTemplate) throw new Error('No PNG output module template is available in this AE installation.');

            om.applyTemplate(pngTemplate);
            // setSettings() can invalidate the OM object, so refresh it after
            // any settings mutation rather than holding a stale reference.
            try {
                om.setSettings({
                    'Output File Info': {
                        'Full Flat Path': thumbFile.fsName
                    },
                    'Post-Render Action': 'None'
                });
            } catch (eSettings) {
                om.file = thumbFile;
            }

            // Make sure the render range is exactly one frame.
            rqi.timeSpanStart = firstFrameTime;
            rqi.timeSpanDuration = frameDuration;
            rqi.skipFrames = 0;
            rqi.render = true;

            // IMPORTANT: RenderQueueItem has no render() method. Rendering is
            // started by the project's RenderQueue.render().
            rq.render();

            if (!thumbFile.exists) {
                var pngs = thumbFile.parent.getFiles('*.png');
                if (pngs && pngs.length) {
                    var stem = thumbFile.name.replace(/\.png$/i, '');
                    var newest = null;
                    for (var pi = 0; pi < pngs.length; pi++) {
                        if (String(pngs[pi].name).indexOf(stem) === 0) {
                            if (!newest || pngs[pi].modified > newest.modified) newest = pngs[pi];
                        }
                    }
                    if (newest) {
                        try { newest.copy(thumbFile); } catch (eCopyThumb) {}
                    }
                }
            }
            rendered = thumbFile.exists && thumbFile.length > 0;
        } catch (eRQ) {
            rendered = false;
        } finally {
            try { if (rqi) rqi.remove(); } catch (eRemoveRQ) {}
        }
    }
    return { rendered: rendered, time: firstFrameTime, frameDuration: frameDuration };
}

function _dc_removeFolderRecursive(folder) {
    if (!folder || !folder.exists) return true;
    var ok = true;
    try {
        var entries = folder.getFiles();
        for (var i = 0; i < entries.length; i++) {
            try {
                if (entries[i] instanceof Folder) _dc_removeFolderRecursive(entries[i]);
                else entries[i].remove();
            } catch (eEntry) { ok = false; }
        }
        try { if (!folder.remove()) ok = false; } catch (eRemove) { ok = false; }
    } catch (eList) { ok = false; }
    return ok;
}

function _dc_makeUniqueLibraryName(parentFolder, requested) {
    var base = _dc_sanitizeFileName(requested);
    var candidate = base;
    var n = 2;
    while (new Folder(parentFolder.fsName + (($.os.indexOf('Win') !== -1) ? '\\' : '/') + candidate).exists) {
        candidate = base + ' (' + n + ')';
        n++;
        if (n > 9999) throw new Error('Could not allocate a unique library name.');
    }
    return candidate;
}

function _dc_restoreSnapshot(tempProjFile, originalProjectFile) {
    // Restoring the snapshot first preserves unsaved edits. When the original
    // project was already saved, save the restored snapshot back to the same
    // project path so the user does not remain attached to a temp .aep file.
    if (!tempProjFile || !tempProjFile.exists) return false;
    try {
        app.open(tempProjFile);
        if (originalProjectFile && originalProjectFile.exists) {
            try { app.project.save(originalProjectFile); } catch (eSaveOriginal) {}
        }
        return true;
    } catch (e) {}
    return false;
}

function savePrecomp(name, extRootFromJS) {
    var resultStr = "error";
    var errorMessage = "";
    undoWrapper("Save Precomp", function() {
        var originalProjectFile = null;
        var tempProjFile = null;
        var restored = false;
        var targetFolder = null;
        var targetFolderCreated = false;
        var assetCommitted = false;

        try {
            // ── 1. Detect the exact selected pre-comp layer ─────────────────
            var info = _dc_getSelectedPrecompInfo();
            if (!info.ok) {
                alert("DeepComp Save Precomp\n\n" + info.message);
                resultStr = "no_selection";
                return;
            }

            var parentComp = app.project.activeItem;
            var sourceComp = parentComp.selectedLayers[0].source;
            originalProjectFile = app.project.file;

            // Name defaults to the source comp / layer name, while allowing the
            // user to provide a custom library name from the panel.
            if (!name || name === "" || name === "undefined") {
                name = prompt("Enter a name for this precomp:", sourceComp.name || info.name);
            }
            if (!name || name === "") { resultStr = "cancel"; return; }
            name = _dc_sanitizeFileName(name);

            var sep = ($.os.indexOf("Win") !== -1) ? "\\" : "/";
            var userLibRoot = getUserLibraryRoot();
            var libDir = new Folder(userLibRoot + sep + "library");
            if (!libDir.exists && !libDir.create()) throw new Error("Could not create DeepComp library folder.");
            var precompsDir = new Folder(libDir.fsName + sep + "Precomps");
            if (!precompsDir.exists && !precompsDir.create()) throw new Error("Could not create Precomps folder.");

            // Never destroy an existing library asset silently. If the user
            // reuses a name, allocate the next deterministic version.
            name = _dc_makeUniqueLibraryName(precompsDir, name);
            targetFolder = new Folder(precompsDir.fsName + sep + name);
            if (!targetFolder.exists) {
                if (!targetFolder.create()) throw new Error("Could not create precomp folder.");
                targetFolderCreated = true;
            }
            var assetsFolder = new Folder(targetFolder.fsName + sep + "Assets");
            if (!assetsFolder.exists && !assetsFolder.create()) throw new Error("Could not create Assets folder.");

            var reducedProjFile = new File(targetFolder.fsName + sep + name + ".aep");
            var thumbFile = new File(targetFolder.fsName + sep + "thumbnail.png");
            var metaFile = new File(targetFolder.fsName + sep + "meta.json");

            // ── 2. Capture a complete snapshot before destructive reduction ─
            var tempFileName = "deepcomp_snapshot_" + (new Date()).getTime() + ".aep";
            tempProjFile = new File(Folder.temp.fsName + sep + tempFileName);
            try {
                app.project.save(tempProjFile);
            } catch (eSnapshot) {
                throw new Error("Could not create a temporary project snapshot. Save the AE project once and try again.\n" + eSnapshot.toString());
            }

            // ── 3. Reduce to ONLY the selected pre-comp source ──────────────
            // This strips unrelated comps/layers while preserving dependencies.
            try {
                app.project.reduceProject([sourceComp]);
            } catch (eReduce) {
                throw new Error("After Effects could not isolate the selected pre-comp.\n" + eReduce.toString());
            }

            // The sourceComp reference can remain usable after reduceProject in
            // most AE versions. Re-find by identity/name defensively.
            var reducedComp = null;
            var sourceCompId = 0;
            try { sourceCompId = sourceComp.id || 0; } catch (eSourceId) {}
            try {
                // Prefer the persistent Item.id so duplicate comp names cannot
                // cause DeepComp to save the wrong composition.
                if (sourceCompId) {
                    for (var rii = 1; rii <= app.project.numItems; rii++) {
                        var riiItem = app.project.item(rii);
                        if (riiItem instanceof CompItem && riiItem.id === sourceCompId) {
                            reducedComp = riiItem;
                            break;
                        }
                    }
                }
                if (!reducedComp) {
                    for (var ri = 1; ri <= app.project.numItems; ri++) {
                        var riItem = app.project.item(ri);
                        if (riItem instanceof CompItem && riItem.name === sourceComp.name) {
                            reducedComp = riItem;
                            break;
                        }
                    }
                }
            } catch (eFindComp) {}
            if (!reducedComp) reducedComp = sourceComp;

            // ── 4. Make the saved library asset portable ───────────────────
            var assetStats = _dc_collectAndRelinkFootage(reducedComp, assetsFolder, sep);

            // ── 5. Save the isolated AEP ────────────────────────────────────
            try {
                app.project.save(reducedProjFile);
            } catch (eSave) {
                throw new Error("Could not save the pre-comp AEP.\n" + eSave.toString());
            }
            if (!reducedProjFile.exists || reducedProjFile.length < 1024) {
                throw new Error("The pre-comp AEP was not written correctly.");
            }
            assetCommitted = true;

            // ── 6. Exact first-frame thumbnail ──────────────────────────────
            var thumbInfo = _dc_renderFirstFrame(reducedComp, thumbFile, sep);
            var rendered = thumbInfo.rendered;

            // ── 7. Rich metadata for future-proof library loading ──────────
            try {
                var frameDuration = reducedComp.frameDuration || (1.0 / (reducedComp.frameRate || 30));
                var meta = '{\n' +
                    '  "schemaVersion": 2,\n' +
                    '  "name": "' + _dc_jsonEscape(name) + '",\n' +
                    '  "sourceComp": "' + _dc_jsonEscape(sourceComp.name) + '",\n' +
                    '  "sourceLayer": "' + _dc_jsonEscape(info.name) + '",\n' +
                    '  "sourceParentComp": "' + _dc_jsonEscape(info.compName) + '",\n' +
                    '  "duration": ' + (reducedComp.duration || 0) + ',\n' +
                    '  "width": ' + reducedComp.width + ',\n' +
                    '  "height": ' + reducedComp.height + ',\n' +
                    '  "frameRate": ' + reducedComp.frameRate + ',\n' +
                    '  "frameDuration": ' + frameDuration + ',\n' +
                    '  "thumbnailTime": ' + thumbInfo.time + ',\n' +
                    '  "thumbnail": ' + (rendered ? '"thumbnail.png"' : 'null') + ',\n' +
                    '  "portableAssets": true,\n' +
                    '  "assetCount": ' + assetStats.copied + ',\n' +
                    '  "assetFailures": ' + assetStats.failed + ',\n' +
                    '  "savedAt": "' + _dc_jsonEscape((new Date()).toString()) + '"\n' +
                    '}';
                metaFile.encoding = "UTF-8";
                metaFile.open("w");
                metaFile.write(meta);
                metaFile.close();
            } catch (eMeta) {
                // Metadata is auxiliary; the AEP is already safely saved.
            }

            // ── 8. Restore original project snapshot ───────────────────────
            restored = _dc_restoreSnapshot(tempProjFile, originalProjectFile);
            if (!restored && originalProjectFile && originalProjectFile.exists) {
                try { app.open(originalProjectFile); restored = true; } catch (eOriginalRestore) {}
            }
            if (!restored) throw new Error("Pre-comp was saved, but DeepComp could not restore the original project snapshot. The snapshot remains in the system temp folder.");

            resultStr = name;
        } catch (e) {
            errorMessage = e.toString();
            resultStr = "error";
            // Best-effort restore whenever an exception occurs after snapshot.
            if (!restored && tempProjFile && tempProjFile.exists) {
                restored = _dc_restoreSnapshot(tempProjFile, originalProjectFile);
            }
            if (!restored && originalProjectFile && originalProjectFile.exists) {
                try { app.open(originalProjectFile); restored = true; } catch (eOriginalRestore2) {}
            }
            // Remove only a newly-created incomplete asset folder. Existing
            // user library entries are never touched by the failure path.
            if (!assetCommitted && targetFolderCreated && targetFolder && targetFolder.exists) {
                try { _dc_removeFolderRecursive(targetFolder); } catch (eCleanupFolder) {}
            }
            alert("DeepComp Save Precomp failed\n\n" + errorMessage);
        } finally {
            try { if (tempProjFile && tempProjFile.exists) tempProjFile.remove(); } catch (eCleanup) {}
        }
    });
    return resultStr;
}

function saveImage(extRootFromJS) {
    var resultStr = "error";
    undoWrapper("Save Selected Image", function() {
        var imageItem = null;

        // Priority 1: check selected layers in the active timeline
        var comp = app.project.activeItem;
        if (comp && comp instanceof CompItem) {
            var layers = comp.selectedLayers;
            for (var li = 0; li < layers.length; li++) {
                var lyr = layers[li];
                if (lyr.source && lyr.source instanceof FootageItem && lyr.source.file) {
                    var ext = lyr.source.file.name.split(".").pop().toLowerCase();
                    if (ext === "png" || ext === "jpg" || ext === "jpeg" || ext === "bmp" || ext === "tga" || ext === "tiff" || ext === "tif" || ext === "gif" || ext === "webp") {
                        imageItem = lyr.source;
                        break;
                    }
                }
            }
        }

        // Priority 2: fall back to Project Panel selection
        if (!imageItem) {
            var items = app.project.selection;
            for (var i = 0; i < items.length; i++) {
                if (items[i] instanceof FootageItem && items[i].file) {
                    imageItem = items[i];
                    break;
                }
            }
        }

        if (!imageItem) {
            alert("Please select an image layer in the timeline, or an image in the Project Panel.");
            resultStr = "no_selection";
            return;
        }

        var srcFile = imageItem.file;
        var sep = ($.os.indexOf("Win") !== -1) ? "\\" : "/";

        var userLibRoot2 = getUserLibraryRoot();
        var libDir    = new Folder(userLibRoot2 + sep + "library");
        if (!libDir.exists) libDir.create();
        var imagesDir = new Folder(libDir.fsName + sep + "Images");
        if (!imagesDir.exists) imagesDir.create();

        var destFile = new File(imagesDir.fsName + sep + srcFile.name);
        try { srcFile.copy(destFile); } catch(eCopy) {}
        resultStr = srcFile.name;
    });
    return resultStr;
}

function importSavedAsset(pathStr) {
    var result = 'error';
    undoWrapper('Import Saved Asset', function() {
        try {
            var importFile = new File(pathStr);
            if (!importFile.exists) {
                alert('DeepComp: Saved pre-comp file not found:\n' + pathStr);
                result = 'not_found';
                return;
            }

            var activeComp = getActiveComp();
            if (!activeComp) { result = 'no_comp'; return; }

            var meta = null;
            try {
                var metaFile = new File(importFile.parent.fsName + (($.os.indexOf('Win') !== -1) ? '\\' : '/') + 'meta.json');
                if (metaFile.exists) {
                    metaFile.encoding = 'UTF-8';
                    metaFile.open('r');
                    meta = JSON.parse(metaFile.read());
                    metaFile.close();
                }
            } catch (eMetaImport) { meta = null; }

            var importOptions = new ImportOptions(importFile);
            var importedRoot = app.project.importFile(importOptions);
            var expectedCompName = meta && meta.sourceComp ? String(meta.sourceComp) : '';
            var importedComp = null;

            function walkForComp(container) {
                if (!container || !container.numItems) return null;
                var firstComp = null;
                for (var i = 1; i <= container.numItems; i++) {
                    var item = container.item(i);
                    if (item instanceof CompItem) {
                        if (!firstComp) firstComp = item;
                        if (expectedCompName && item.name === expectedCompName) return item;
                    }
                    if (item instanceof FolderItem) {
                        var nested = walkForComp(item);
                        if (nested) return nested;
                    }
                }
                return firstComp;
            }

            if (importedRoot instanceof CompItem) importedComp = importedRoot;
            else if (importedRoot instanceof FolderItem) importedComp = walkForComp(importedRoot);

            if (!importedComp) {
                alert('DeepComp: The saved AEP imported, but no valid composition was found.');
                result = 'no_comp_in_asset';
                return;
            }

            // Sanity-check metadata when available to prevent an accidental
            // import of a similarly named composition.
            if (meta) {
                var mismatches = [];
                if (meta.width && Number(meta.width) !== Number(importedComp.width)) mismatches.push('width');
                if (meta.height && Number(meta.height) !== Number(importedComp.height)) mismatches.push('height');
                if (meta.frameRate && Math.abs(Number(meta.frameRate) - Number(importedComp.frameRate)) > 0.001) mismatches.push('frameRate');
                if (mismatches.length) {
                    // Don't hard-fail legacy files; the exact comp name is the
                    // primary identity, metadata is a secondary confidence check.
                }
            }

            var newLayer = activeComp.layers.add(importedComp);
            if (!newLayer) {
                alert('DeepComp: Could not add the saved pre-comp to the active timeline.');
                result = 'layer_add_failed';
                return;
            }

            // Insert where the user's playhead is and preserve the imported
            // composition's full source duration. AE automatically handles the
            // layer/source timing relationship when source is added.
            try { newLayer.startTime = activeComp.time; } catch (eStart) {}
            try { newLayer.name = importedComp.name; } catch (eName) {}

            try {
                for (var li = 1; li <= activeComp.numLayers; li++) activeComp.layer(li).selected = false;
                newLayer.selected = true;
            } catch (eSelect) {}
            result = importedComp.name;
        } catch (e) {
            alert('DeepComp Import failed\n\n' + e.toString());
            result = 'error';
        }
    });
    return result;
}

function openEffectsPresetsPanel() {
    var id = app.findMenuCommandId("Effects & Presets");
    if (id > 0) {
        app.executeCommand(id);
    } else {
        app.executeCommand(3718);
    }
}

function getLastAppliedEffect() {
    var comp = app.project.activeItem;
    if (!comp || !(comp instanceof CompItem)) return "NO_COMP";
    var layers = comp.selectedLayers;
    if (layers.length === 0) return "NO_LAYER";
    var layer = layers[0];
    var fx = layer.property("ADBE Effect Parade") ||
              layer.property("Effects") ||
              layer.property(5);
    if (!fx || fx.numProperties === 0) return "NO_EFFECTS";
    var lastFx = fx.property(fx.numProperties);
    return lastFx ? lastFx.name : "NO_EFFECTS";
}

function getAllEffectsOnLayer() {
    var comp = app.project.activeItem;
    if (!comp || !(comp instanceof CompItem)) return "[]";
    var layers = comp.selectedLayers;
    if (layers.length === 0) return "[]";
    var layer = layers[0];
    var fx = layer.property("ADBE Effect Parade") ||
              layer.property("Effects") ||
              layer.property(5);
    if (!fx || fx.numProperties === 0) return "[]";
    var names = [];
    for (var i = 1; i <= fx.numProperties; i++) {
        names.push(fx.property(i).name);
    }
    var json = "[";
    for (var j = 0; j < names.length; j++) {
        json += '"' + names[j].replace(/"/g, '\\"') + '"';
        if (j < names.length - 1) json += ",";
    }
    json += "]";
    return json;
}

function scanInstalledPlugins() {
    var pluginNames = [];
    var pluginDirs = [];
    pluginDirs.push(new Folder("C:/Program Files/Adobe/Adobe After Effects 2025/Support Files/Plug-ins"));
    pluginDirs.push(new Folder("C:/Program Files/Adobe/Adobe After Effects 2024/Support Files/Plug-ins"));
    pluginDirs.push(new Folder("C:/Program Files/Adobe/Adobe After Effects 2023/Support Files/Plug-ins"));
    pluginDirs.push(new Folder("C:/Program Files/Adobe/Common/Plug-ins/7.0/MediaCore"));
    pluginDirs.push(new Folder("C:/Program Files/Adobe/Common/Plug-ins/CSX/MediaCore"));
    pluginDirs.push(new Folder("/Applications/Adobe After Effects 2025/Plug-ins"));
    pluginDirs.push(new Folder("/Applications/Adobe After Effects 2024/Plug-ins"));
    pluginDirs.push(new Folder("/Library/Application Support/Adobe/Common/Plug-ins/7.0/MediaCore"));
    
    function scanDir(folder) {
        try {
            if (!folder.exists) return;
            var items = folder.getFiles();
            for (var i = 0; i < items.length; i++) {
                var item = items[i];
                if (item instanceof Folder) {
                    scanDir(item);
                } else if (item instanceof File) {
                    var name = item.name;
                    if (name.match(/\.(aex|plugin)$/i)) {
                        var displayName = name.replace(/\.(aex|plugin)$/i, '');
                        pluginNames.push(displayName);
                    }
                }
            }
        } catch(e) {}
    }
    for (var d = 0; d < pluginDirs.length; d++) { scanDir(pluginDirs[d]); }
    var unique = [];
    var seen = {};
    for (var j = 0; j < pluginNames.length; j++) {
        if (!seen[pluginNames[j]]) { seen[pluginNames[j]] = true; unique.push(pluginNames[j]); }
    }
    var json = "[";
    for (var k = 0; k < unique.length; k++) {
        json += '"' + unique[k].replace(/\\/g, '\\\\').replace(/"/g, '\\"') + '"';
        if (k < unique.length - 1) json += ",";
    }
    json += "]";
    return json;
}

function getAllInstalledEffects() {
    var results = [];
    try {
        var effectsCollection = app.effects;
        for (var i = 0; i < effectsCollection.length; i++) {
            var fx = effectsCollection[i];
            try {
                var name      = fx.displayName || fx.name || "";
                var category  = fx.category    || "Other";
                var matchName = fx.matchName   || name;
                if (name) { results.push({ n: name, c: category, m: matchName }); }
            } catch(eInner) {}
        }
    } catch(eOuter) {
        return "UNAVAILABLE";
    }
    var parts = [];
    for (var j = 0; j < results.length; j++) {
        var r = results[j];
        var n = r.n.replace(/\\/g,"\\\\").replace(/"/g,'\\"');
        var c = r.c.replace(/\\/g,"\\\\").replace(/"/g,'\\"');
        var m = r.m.replace(/\\/g,"\\\\").replace(/"/g,'\\"');
        parts.push('{"n":"' + n + '","c":"' + c + '","m":"' + m + '"}');
    }
    return "[" + parts.join(",") + "]";
}

function getUserPresetsFromAE() {
    var results = [];
    var presetDirs = [];
    var win_docs = new Folder(
        Folder.userData.fsName + "/AppData/Roaming/Adobe/After Effects/" +
        app.version.split(".")[0] + ".x/User Presets"
    );
    presetDirs.push(win_docs);
    var winVersions = ["26.0","25.0","24.0","23.0","22.0","21.0","18.0","17.0","16.0"];
    for (var vi = 0; vi < winVersions.length; vi++) {
        presetDirs.push(new Folder(
            Folder.userData.fsName + "/AppData/Roaming/Adobe/After Effects/" +
            winVersions[vi] + "/User Presets"
        ));
        presetDirs.push(new Folder(
            "C:/Program Files/Adobe/Adobe After Effects " +
            (2000 + parseInt(winVersions[vi])) +
            "/Support Files/Presets"
        ));
    }
    presetDirs.push(new Folder(
        Folder.userData.fsName + "/Library/Application Support/Adobe/After Effects/" +
        app.version.split(".")[0] + ".x/User Presets"
    ));
    presetDirs.push(new Folder("/Applications/Adobe After Effects 2026/Presets"));
    presetDirs.push(new Folder("/Applications/Adobe After Effects 2025/Presets"));
    presetDirs.push(new Folder("/Applications/Adobe After Effects 2024/Presets"));

    var seen = {};
    function scanPresetDir(folder, parentLabel) {
        if (!folder || !folder.exists) return;
        try {
            var items = folder.getFiles();
            for (var i = 0; i < items.length; i++) {
                var item = items[i];
                if (item instanceof Folder) {
                    scanPresetDir(item, item.name);
                } else if (item instanceof File) {
                    if (item.name.match(/\.ffx$/i)) {
                        var displayName = item.name.replace(/\.ffx$/i, "");
                        var pathStr = item.fsName.replace(/\\/g, "\\\\");
                        var key = displayName.toLowerCase();
                        if (!seen[key]) {
                            seen[key] = true;
                            results.push({ n: displayName, p: pathStr, f: parentLabel || "Presets" });
                        }
                    }
                }
            }
        } catch(e) {}
    }
    for (var d = 0; d < presetDirs.length; d++) { scanPresetDir(presetDirs[d], presetDirs[d].name); }
    var parts = [];
    for (var j = 0; j < results.length; j++) {
        var r = results[j];
        var n = r.n.replace(/\\/g,"\\\\").replace(/"/g,'\\"');
        var p = r.p.replace(/"/g,'\\"');
        var f = r.f.replace(/\\/g,"\\\\").replace(/"/g,'\\"');
        parts.push('{"n":"' + n + '","p":"' + p + '","f":"' + f + '"}');
    }
    return "[" + parts.join(",") + "]";
}

function applyEffectByMatchName(matchName, displayName) {
    undoWrapper("Apply Effect: " + displayName, function() {
        var comp = getActiveComp();
        if (!comp) return;
        var layers = comp.selectedLayers;
        if (layers.length === 0) {
            return alert("Please select a layer first, then click the effect chip.");
        }
        for (var i = 0; i < layers.length; i++) {
            var layer = layers[i];
            var effectsGroup = layer.property("ADBE Effect Parade") ||
                               layer.property("Effects") || layer.property(5);
            if (!effectsGroup) continue;
            var applied = false;
            try { effectsGroup.addProperty(matchName); applied = true; } catch(e1) {}
            if (!applied) {
                try { effectsGroup.addProperty(displayName); applied = true; } catch(e2) {}
            }
            if (!applied) {
                alert("Could not apply \"" + displayName + "\".\n" +
                      "It may not be installed, or the layer type may not support it.");
            }
        }
    });
}

// ═══════════════════════════════════════════════════════════════════════════════
//  V2.0 EXTENDED AE TOOLS
// ═══════════════════════════════════════════════════════════════════════════════

function addText() {
    undoWrapper("Add Text Layer", function() {
        var comp = getActiveComp();
        if (!comp) return;
        var selected = comp.selectedLayers;
        var layer = comp.layers.addText("Text");
        layer.property("Position").setValue([comp.width / 2, comp.height / 2, 0]);
        if (selected && selected.length > 0) {
            layer.inPoint = selected[0].inPoint;
            layer.outPoint = selected[0].outPoint;
            moveAboveSelected(layer, selected);
        }
    });
}

function addShape() {
    undoWrapper("Add Shape Layer", function() {
        var comp = getActiveComp();
        if (!comp) return;
        var selected = comp.selectedLayers;
        var layer = comp.layers.addShape();
        layer.name = "Shape Layer";
        var shapeContents = layer.property("ADBE Root Vectors Group");
        var rect = shapeContents.addProperty("ADBE Vector Shape - Rect");
        rect.property("ADBE Vector Rect Size").setValue([comp.width * 0.4, comp.height * 0.4]);
        var fill = shapeContents.addProperty("ADBE Vector Graphic - Fill");
        fill.property("ADBE Vector Fill Color").setValue([1, 1, 1]);
        if (selected && selected.length > 0) {
            layer.inPoint = selected[0].inPoint;
            layer.outPoint = selected[0].outPoint;
            moveAboveSelected(layer, selected);
        }
    });
}

function duplicateLayer() {
    undoWrapper("Duplicate Layer", function() {
        var comp = getActiveComp();
        if (!comp) return;
        var selected = comp.selectedLayers;
        if (!selected || selected.length === 0) return alert("Select layers to duplicate.");
        for (var i = 0; i < selected.length; i++) {
            selected[i].duplicate();
        }
    });
}

function trimInPoint() {
    undoWrapper("Trim In Point", function() {
        var comp = getActiveComp();
        if (!comp) return;
        var selected = comp.selectedLayers;
        if (!selected || selected.length === 0) return alert("Select layers to trim.");
        for (var i = 0; i < selected.length; i++) {
            selected[i].inPoint = comp.time;
        }
    });
}

function trimOutPoint() {
    undoWrapper("Trim Out Point", function() {
        var comp = getActiveComp();
        if (!comp) return;
        var selected = comp.selectedLayers;
        if (!selected || selected.length === 0) return alert("Select layers to trim.");
        for (var i = 0; i < selected.length; i++) {
            selected[i].outPoint = comp.time;
        }
    });
}

function splitLayers() {
    undoWrapper("Split Layers", function() {
        var comp = getActiveComp();
        if (!comp) return;
        var selected = comp.selectedLayers;
        if (!selected || selected.length === 0) return alert("Select layers to split.");
        var t = comp.time;
        for (var i = 0; i < selected.length; i++) {
            var lyr = selected[i];
            if (t > lyr.inPoint && t < lyr.outPoint) {
                var dup = lyr.duplicate();
                lyr.outPoint = t;
                dup.inPoint = t;
            }
        }
    });
}

function fitToComp(mode) {
    undoWrapper("Fit to Comp", function() {
        var comp = getActiveComp();
        if (!comp) return;
        var selected = comp.selectedLayers;
        if (!selected || selected.length === 0) return alert("Select a layer.");
        for (var i = 0; i < selected.length; i++) {
            var lyr = selected[i];
            var rect = lyr.sourceRectAtTime(comp.time, false);
            var w = rect.width;
            var h = rect.height;
            if (w === 0 || h === 0) continue;
            var curScale = lyr.property("Scale").value;
            var sx = (comp.width / w) * 100;
            var sy = (comp.height / h) * 100;
            if (mode === "width") {
                lyr.property("Scale").setValue([sx, (curScale[1] / curScale[0]) * sx, curScale[2]]);
            } else if (mode === "height") {
                lyr.property("Scale").setValue([(curScale[0] / curScale[1]) * sy, sy, curScale[2]]);
            } else {
                lyr.property("Scale").setValue([sx, sy, curScale[2]]);
            }
            lyr.property("Position").setValue([comp.width / 2, comp.height / 2, lyr.property("Position").value[2]]);
        }
    });
}

function sequenceLayers(frameOffset) {
    undoWrapper("Sequence Layers", function() {
        var comp = getActiveComp();
        if (!comp) return;
        var selected = comp.selectedLayers;
        if (!selected || selected.length < 2) return alert("Select 2 or more layers to sequence.");
        var offset = (typeof frameOffset === "number" ? frameOffset : 0) / comp.frameRate;
        var currentTime = selected[0].inPoint;
        for (var i = 0; i < selected.length; i++) {
            var lyr = selected[i];
            var dur = lyr.outPoint - lyr.inPoint;
            lyr.startTime = currentTime - (lyr.inPoint - lyr.startTime);
            lyr.inPoint = currentTime;
            lyr.outPoint = currentTime + dur;
            currentTime += (dur - offset);
        }
    });
}

function removeAllEffects() {
    undoWrapper("Remove All Effects", function() {
        var comp = getActiveComp();
        if (!comp) return;
        var selected = comp.selectedLayers;
        if (!selected || selected.length === 0) return alert("Select layers.");
        for (var i = 0; i < selected.length; i++) {
            var fx = selected[i].property("ADBE Effect Parade") || selected[i].property("Effects");
            if (fx) {
                while (fx.numProperties > 0) {
                    fx.property(1).remove();
                }
            }
        }
    });
}

var _copiedPropsBuffer = null;

function copyProperties() {
    var comp = getActiveComp();
    if (!comp) return "error";
    var selected = comp.selectedLayers;
    if (!selected || selected.length === 0) return "no_layer";
    var lyr = selected[0];
    _copiedPropsBuffer = {
        position: lyr.property("Position").value,
        scale: lyr.property("Scale").value,
        rotation: lyr.property("Rotation") ? lyr.property("Rotation").value : 0,
        opacity: lyr.property("Opacity").value
    };
    return "ok";
}

function pasteProperties() {
    undoWrapper("Paste Properties", function() {
        if (!_copiedPropsBuffer) return alert("No properties copied yet.");
        var comp = getActiveComp();
        if (!comp) return;
        var selected = comp.selectedLayers;
        if (!selected || selected.length === 0) return alert("Select target layers.");
        for (var i = 0; i < selected.length; i++) {
            var lyr = selected[i];
            try { lyr.property("Position").setValue(_copiedPropsBuffer.position); } catch(e) {}
            try { lyr.property("Scale").setValue(_copiedPropsBuffer.scale); } catch(e) {}
            try { if (lyr.property("Rotation")) lyr.property("Rotation").setValue(_copiedPropsBuffer.rotation); } catch(e) {}
            try { lyr.property("Opacity").setValue(_copiedPropsBuffer.opacity); } catch(e) {}
        }
    });
}

function renameSelectedLayers(baseName) {
    undoWrapper("Rename Layers", function() {
        var comp = getActiveComp();
        if (!comp) return;
        var selected = comp.selectedLayers;
        if (!selected || selected.length === 0) return;
        for (var i = 0; i < selected.length; i++) {
            selected[i].name = (selected.length > 1) ? (baseName + " " + (i + 1)) : baseName;
        }
    });
}

// ═══════════════════════════════════════════════════════════════════════════════
//  AUTOMATIC TEXT PRESET KEYFRAME SYSTEM
// ═══════════════════════════════════════════════════════════════════════════════

function _collectAnimatableProps(group, list) {
    if (!group) return;
    for (var i = 1; i <= group.numProperties; i++) {
        var prop = group.property(i);
        if (prop.propertyType === PropertyType.PROPERTY) {
            if (prop.numKeys > 0) {
                list.push(prop);
            }
        } else if (prop.propertyType === PropertyType.INDEXED_GROUP || prop.propertyType === PropertyType.NAMED_GROUP) {
            _collectAnimatableProps(prop, list);
        }
    }
}

function applyPresetWithKeyframeAdaptation(pathStr) {
    var resultStatus = "error";
    undoWrapper("Apply Preset & Adapt Timing", function() {
        var comp = getActiveComp();
        if (!comp) return;
        var presetFile = new File(pathStr);
        if (!presetFile.exists) return alert("Preset file not found: " + pathStr);

        var selected = comp.selectedLayers;
        if (!selected || selected.length === 0) return alert("Select a layer to apply preset.");

        for (var li = 0; li < selected.length; li++) {
            var layer = selected[li];
            var targetIn = layer.inPoint;
            var targetOut = layer.outPoint;

            // 1. Snapshot existing keyframe timestamps across all properties
            var beforeProps = [];
            _collectAnimatableProps(layer, beforeProps);
            var beforeSnapshot = [];
            for (var b = 0; b < beforeProps.length; b++) {
                var p = beforeProps[b];
                var kTimes = [];
                for (var ki = 1; ki <= p.numKeys; ki++) {
                    kTimes.push(p.keyTime(ki));
                }
                beforeSnapshot.push({ prop: p, times: kTimes });
            }

            // 2. Apply the .ffx preset
            layer.applyPreset(presetFile);
            fixTextPresetEffectPoints(layer, comp);

            // 3. Collect all properties after preset application
            var afterProps = [];
            _collectAnimatableProps(layer, afterProps);

            // 4. Identify newly introduced keyframes and find the earliest keyframe time
            var earliestPresetKey = 999999;
            var newKeyEntries = [];

            for (var a = 0; a < afterProps.length; a++) {
                var propAfter = afterProps[a];
                var oldMatch = null;
                for (var s = 0; s < beforeSnapshot.length; s++) {
                    if (beforeSnapshot[s].prop === propAfter) {
                        oldMatch = beforeSnapshot[s];
                        break;
                    }
                }

                var newlyAddedIndices = [];
                if (!oldMatch) {
                    // All keys on this property are new
                    for (var k = 1; k <= propAfter.numKeys; k++) {
                        var kt = propAfter.keyTime(k);
                        if (kt < earliestPresetKey) earliestPresetKey = kt;
                        newlyAddedIndices.push(k);
                    }
                } else {
                    // Check if new keys exist
                    for (var k2 = 1; k2 <= propAfter.numKeys; k2++) {
                        var kt2 = propAfter.keyTime(k2);
                        var isOld = false;
                        for (var ot = 0; ot < oldMatch.times.length; ot++) {
                            if (Math.abs(oldMatch.times[ot] - kt2) < 0.0001) {
                                isOld = true;
                                break;
                            }
                        }
                        if (!isOld) {
                            if (kt2 < earliestPresetKey) earliestPresetKey = kt2;
                            newlyAddedIndices.push(k2);
                        }
                    }
                }

                if (newlyAddedIndices.length > 0) {
                    newKeyEntries.push({ prop: propAfter, indices: newlyAddedIndices });
                }
            }

            // 5. If preset keyframes were detected, calculate shift and reposition them to targetIn
            if (earliestPresetKey !== 999999 && newKeyEntries.length > 0) {
                var shift = targetIn - earliestPresetKey;
                if (Math.abs(shift) > 0.001) {
                    for (var e = 0; e < newKeyEntries.length; e++) {
                        var entry = newKeyEntries[e];
                        var targetProp = entry.prop;
                        // Snapshot keyframe data before moving
                        var keyData = [];
                        for (var i = 1; i <= targetProp.numKeys; i++) {
                            var t = targetProp.keyTime(i);
                            var v = targetProp.keyValue(i);
                            var inEase = null, outEase = null;
                            var inInterp = null, outInterp = null;
                            try { inEase = targetProp.keyInTemporalEase(i); } catch(eEase) {}
                            try { outEase = targetProp.keyOutTemporalEase(i); } catch(eEase2) {}
                            try { inInterp = targetProp.keyInInterpolationType(i); } catch(eInt) {}
                            try { outInterp = targetProp.keyOutInterpolationType(i); } catch(eInt2) {}
                            keyData.push({
                                time: t + shift,
                                value: v,
                                inEase: inEase,
                                outEase: outEase,
                                inInterp: inInterp,
                                outInterp: outInterp
                            });
                        }

                        // Re-create shifted keys
                        while (targetProp.numKeys > 0) {
                            targetProp.removeKey(1);
                        }
                        for (var kd = 0; kd < keyData.length; kd++) {
                            var item = keyData[kd];
                            var newKeyIndex = targetProp.addKey(item.time);
                            targetProp.setValueAtKey(newKeyIndex, item.value);
                            try {
                                if (item.inEase && item.outEase) {
                                    targetProp.setTemporalEaseAtKey(newKeyIndex, item.inEase, item.outEase);
                                }
                            } catch(eSetEase) {}
                            try {
                                if (item.inInterp !== null && item.outInterp !== null) {
                                    targetProp.setInterpolationTypeAtKey(newKeyIndex, item.inInterp, item.outInterp);
                                }
                            } catch(eSetInt) {}
                        }
                    }
                }
            }
        }
        resultStatus = "ok";
    });
    return resultStatus;
}

// ═══════════════════════════════════════════════════════════════════════════════
//  AE HEALTH & CACHE MONITOR
// ═══════════════════════════════════════════════════════════════════════════════

function getAEHealthStats() {
    var memStr = "{}";
    try {
        var sizes = app.memorySizes;
        var total = sizes ? (sizes.appMemorySize || 0) : 0;
        var used = sizes ? (sizes.usedMemorySize || 0) : 0;
        var comps = 0;
        if (app.project) {
            for (var i = 1; i <= app.project.numItems; i++) {
                if (app.project.item(i) instanceof CompItem) comps++;
            }
        }
        memStr = '{"appMemory":"' + total + '","usedMemory":"' + used + '","comps":' + comps + ',"version":"' + app.version + '"}';
    } catch(e) {
        memStr = '{"error":"' + e.toString().replace(/"/g, '\\"') + '"}';
    }
    return memStr;
}

function purgeAECache() {
    undoWrapper("Purge All Memory & Cache", function() {
        try {
            app.purge(PurgeTarget.ALL_CACHES);
        } catch(e) {
            try {
                app.purge(PurgeTarget.IMAGE_CACHES);
                app.purge(PurgeTarget.UNDO_CACHES);
            } catch(e2) {}
        }
    });
    return "ok";
}

// ═══════════════════════════════════════════════════════════════════════════════
//  SFX SOUND DESIGN LIBRARY — AE HOST BRIDGE
// ═══════════════════════════════════════════════════════════════════════════════

function findExistingFootageByPath(pathStr) {
    if (!app.project) return null;
    var targetFile = new File(pathStr);
    var targetFsName = targetFile.fsName ? targetFile.fsName.toLowerCase() : "";
    for (var i = 1; i <= app.project.numItems; i++) {
        var item = app.project.item(i);
        if (item instanceof FootageItem && item.file && item.file.fsName) {
            if (item.file.fsName.toLowerCase() === targetFsName) {
                return item;
            }
        }
    }
    return null;
}

function insertSFX(pathStr, displayName, insertMode, offsetSec, trimInSec, trimOutSec) {
    var resultStr = "error";
    undoWrapper("DeepComp - Insert SFX", function() {
        var comp = getActiveComp();
        if (!comp) {
            resultStr = "NO_ACTIVE_COMP";
            return;
        }

        var sfxFile = new File(pathStr);
        if (!sfxFile.exists) {
            resultStr = "FILE_NOT_FOUND";
            return;
        }

        offsetSec = (typeof offsetSec === "number") ? offsetSec : parseFloat(offsetSec || 0);
        if (isNaN(offsetSec)) offsetSec = 0;

        trimInSec = (typeof trimInSec === "number") ? trimInSec : parseFloat(trimInSec || 0);
        if (isNaN(trimInSec)) trimInSec = 0;

        trimOutSec = (typeof trimOutSec === "number") ? trimOutSec : parseFloat(trimOutSec || 0);
        if (isNaN(trimOutSec)) trimOutSec = 0;

        // 1. Prevent duplicate footage import if already in project
        var footage = findExistingFootageByPath(pathStr);
        if (!footage) {
            try {
                var importOptions = new ImportOptions(sfxFile);
                footage = app.project.importFile(importOptions);
            } catch(eImp) {
                resultStr = "IMPORT_FAILED: " + eImp.toString();
                return;
            }
        }

        if (!footage) {
            resultStr = "FOOTAGE_NULL";
            return;
        }

        // 2. Determine base insertion time based on mode
        var baseTime = comp.time;
        if (insertMode === "selected_start" || insertMode === "smart") {
            if (comp.selectedLayers && comp.selectedLayers.length > 0) {
                baseTime = comp.selectedLayers[0].inPoint;
            }
        } else if (insertMode === "selected_end") {
            if (comp.selectedLayers && comp.selectedLayers.length > 0) {
                baseTime = comp.selectedLayers[0].outPoint;
            }
        }

        var insertTime = baseTime + offsetSec;
        if (insertTime < 0) insertTime = 0;

        // 3. Add audio layer to comp
        var layer = comp.layers.add(footage);
        if (!layer) {
            resultStr = "LAYER_ADD_FAILED";
            return;
        }

        // 4. Rename layer to display name
        if (displayName && displayName !== "" && displayName !== "undefined") {
            layer.name = displayName;
        }

        // 5. Handle trimming without modifying source file
        if (trimOutSec > trimInSec && trimOutSec > 0) {
            var dur = trimOutSec - trimInSec;
            layer.startTime = insertTime - trimInSec;
            layer.inPoint = insertTime;
            layer.outPoint = insertTime + dur;
        } else if (trimInSec > 0) {
            layer.startTime = insertTime - trimInSec;
            layer.inPoint = insertTime;
        } else {
            layer.startTime = insertTime;
        }

        var mins = Math.floor(insertTime / 60);
        var secs = Math.floor(insertTime % 60);
        var frames = Math.floor((insertTime % 1) * (comp.frameRate || 30));
        var timeFormatted = (mins < 10 ? "0" + mins : mins) + ":" +
                            (secs < 10 ? "0" + secs : secs) + ":" +
                            (frames < 10 ? "0" + frames : frames);

        resultStr = '{"status":"ok","insertedTime":' + insertTime + ',"formattedTime":"' + timeFormatted + '","layerName":"' + layer.name.replace(/"/g, '\\"') + '"}';
    });
    return resultStr;
}

function insertSoundStack(stackJsonStr) {
    var resultStr = "error";
    undoWrapper("DeepComp - Insert Sound Stack", function() {
        var comp = getActiveComp();
        if (!comp) {
            resultStr = "NO_ACTIVE_COMP";
            return;
        }

        var stackData = null;
        try {
            eval("stackData = " + stackJsonStr + ";");
        } catch(eParse) {
            resultStr = "PARSE_ERROR: " + eParse.toString();
            return;
        }

        if (!stackData || !stackData.items || stackData.items.length === 0) {
            resultStr = "EMPTY_STACK";
            return;
        }

        var baseTime = comp.time;
        if (stackData.insertMode === "selected_start" && comp.selectedLayers && comp.selectedLayers.length > 0) {
            baseTime = comp.selectedLayers[0].inPoint;
        }

        var insertedCount = 0;
        for (var i = 0; i < stackData.items.length; i++) {
            var item = stackData.items[i];
            if (!item || !item.filePath) continue;

            var sfxFile = new File(item.filePath);
            if (!sfxFile.exists) continue;

            var footage = findExistingFootageByPath(item.filePath);
            if (!footage) {
                try {
                    var importOptions = new ImportOptions(sfxFile);
                    footage = app.project.importFile(importOptions);
                } catch(e) { continue; }
            }
            if (!footage) continue;

            var offset = (typeof item.offset === "number") ? item.offset : parseFloat(item.offset || 0);
            if (isNaN(offset)) offset = 0;

            var itemInsertTime = baseTime + offset;
            if (itemInsertTime < 0) itemInsertTime = 0;

            var layer = comp.layers.add(footage);
            if (layer) {
                if (item.displayName) layer.name = item.displayName;
                layer.startTime = itemInsertTime;
                insertedCount++;
            }
        }

        var mins = Math.floor(baseTime / 60);
        var secs = Math.floor(baseTime % 60);
        var frames = Math.floor((baseTime % 1) * (comp.frameRate || 30));
        var timeFormatted = (mins < 10 ? "0" + mins : mins) + ":" +
                            (secs < 10 ? "0" + secs : secs) + ":" +
                            (frames < 10 ? "0" + frames : frames);

        resultStr = '{"status":"ok","count":' + insertedCount + ',"formattedTime":"' + timeFormatted + '"}';
    });
    return resultStr;
}


// ══════════════════════════════════════════════════════════════════════════════
//  SFX FOLDER PICKER  (opens native OS folder dialog, returns path string)
// ══════════════════════════════════════════════════════════════════════════════
function pickFolderForSFX() {
    try {
        var folder = Folder.selectDialog("Select a folder of SFX audio files");
        if (folder) {
            return folder.fsName; // Returns the native file-system path e.g. C:\Users\…\SFX
        }
    } catch (e) {}
    return "null";
}
